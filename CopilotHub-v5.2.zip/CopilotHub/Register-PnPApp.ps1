<#
.SYNOPSIS
  One-time: registers an Entra app for PnP PowerShell interactive sign-in.

.DESCRIPTION
  Since September 2024, PnP PowerShell no longer ships with a shared
  multi-tenant app. Each tenant must register its own Entra app before
  Connect-PnPOnline -Interactive will work.

  This script tries two paths:

    1. If PnP.PowerShell 2.x is loaded (PowerShell 7.2+), it calls
       Register-PnPEntraIDAppForInteractiveLogin and prints the ClientId.

    2. If that cmdlet isn't available (older PnP, Windows PowerShell 5.1),
       it prints step-by-step instructions for registering the app in the
       Entra portal manually. This always works and takes about 2 minutes.

  Either way, the app uses DELEGATED permissions only - it can do only
  what the signed-in user can do. It is NOT granted tenant-wide
  application permissions like Sites.FullControl.All.

.EXAMPLE
  .\Register-PnPApp.ps1 -Tenant contoso.onmicrosoft.com
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string] $Tenant,

    [string] $AppName = "PnP-CopilotHub-Deploy"
)

$ErrorActionPreference = 'Stop'

$cmd = Get-Command Register-PnPEntraIDAppForInteractiveLogin -ErrorAction SilentlyContinue

if ($cmd) {
    Write-Host ""
    Write-Host "Registering Entra app '$AppName' in tenant '$Tenant'." -ForegroundColor Cyan
    Write-Host "Sign in as a Global Administrator when the browser opens."
    Write-Host ""

    Register-PnPEntraIDAppForInteractiveLogin `
        -ApplicationName $AppName `
        -Tenant          $Tenant `
        -Interactive

    Write-Host ""
    Write-Host "Done. Copy the ClientId printed above into Config.psd1 -> ClientId." -ForegroundColor Green
    Write-Host "Allow ~1 minute for the registration to propagate before running Deploy-CopilotHub.ps1."
    return
}

# Fallback: manual portal registration
Write-Host ""
Write-Host "The Register-PnPEntraIDAppForInteractiveLogin cmdlet is not available." -ForegroundColor Yellow
Write-Host "This usually means you're on Windows PowerShell 5.1 with PnP.PowerShell 1.x."
Write-Host ""
Write-Host "Register the app manually in the Entra portal - it takes about 2 minutes:" -ForegroundColor Cyan
Write-Host ""
Write-Host "  1. Open https://entra.microsoft.com (sign in as Global Admin)"
Write-Host "  2. Identity -> Applications -> App registrations -> New registration"
Write-Host "     - Name:           $AppName"
Write-Host "     - Account types:  Accounts in this organizational directory only (single tenant)"
Write-Host "     - Redirect URI:   Public client/native (mobile & desktop) -> http://localhost"
Write-Host "     Click Register."
Write-Host ""
Write-Host "  3. On the Overview page, copy the 'Application (client) ID'."
Write-Host "     Paste it into Config.psd1 -> ClientId."
Write-Host ""
Write-Host "  4. Left nav -> API permissions -> Add a permission:"
Write-Host "     - SharePoint     -> Delegated -> AllSites.FullControl"
Write-Host "     - Microsoft Graph -> Delegated -> User.Read"
Write-Host "     Remove the default 'User.Read' if it was auto-added twice."
Write-Host "     Click 'Grant admin consent for $Tenant'."
Write-Host ""
Write-Host "     These are the MINIMUM permissions PnP needs for this workflow."
Write-Host "     Both are delegated, so the app inherits your user scope."
Write-Host ""
Write-Host "  5. Left nav -> Authentication -> 'Allow public client flows' -> Yes -> Save."
Write-Host ""
Write-Host "  6. Wait ~1 minute for propagation, then run .\Deploy-CopilotHub.ps1." -ForegroundColor Green
Write-Host ""
Write-Host "All permissions above are DELEGATED, so the app can only do what" -ForegroundColor DarkGray
Write-Host "the signed-in user (you) can do. There is no Sites.FullControl.All" -ForegroundColor DarkGray
Write-Host "application permission and no tenant-wide grant." -ForegroundColor DarkGray
