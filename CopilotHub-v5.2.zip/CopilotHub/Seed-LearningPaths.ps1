﻿<#
.SYNOPSIS
  Seeds the Learning Paths list with verified Microsoft Learn and GitHub courses.

.DESCRIPTION
  Reads SiteUrl from Config.psd1. Signs in interactively as a SharePoint
  Administrator. Idempotent - skips rows that already exist (matched on Title).

.EXAMPLE
  .\Seed-LearningPaths.ps1
#>
[CmdletBinding()]
param(
    [string] $ConfigPath  = (Join-Path $PSScriptRoot 'Config.psd1'),
    [string] $ListTitle   = "Learning Paths",
    # When called from Deploy-CopilotHub.ps1 the site connection is already open.
    # Pass -SkipConnect to reuse it and avoid a second browser sign-in prompt.
    [switch] $SkipConnect
)

$ErrorActionPreference = 'Stop'

if (-not (Test-Path $ConfigPath)) {
    throw "Config file not found: $ConfigPath"
}
$cfg = Import-PowerShellDataFile -Path $ConfigPath

foreach ($k in 'SiteUrl') {
    if ([string]::IsNullOrWhiteSpace($cfg.$k)) {
        throw "Config.psd1 is missing required value: $k"
    }
}
if (-not $SkipConnect) {
    foreach ($k in 'Tenant','ClientId') {
        if ([string]::IsNullOrWhiteSpace($cfg.$k)) {
            throw "Config.psd1 is missing required value: $k"
        }
    }
}

# ---------------------------------------------------------------------------
# Verified Microsoft Learn and GitHub courses (checked September 2026).
#   Product / Audience / Requirement / Level values must match the choices of
#   the CopilotProduct, CopilotAudience, CopilotRequirement, and CopilotLevel
#   site columns. Duration is set only where it is known for the current
#   version of the course.
# ---------------------------------------------------------------------------
$courses = @(
    @{ Title="Build foundational generative AI skills"
       Product="Copilot Chat"; Audience="End User"; Requirement="Required"
       Duration=$null; Level="Beginner"
       Url="https://learn.microsoft.com/en-us/training/paths/explore-microsoft-365-copilot-business-chat/" },

    @{ Title="Work smarter with AI"
       Product="Copilot Chat"; Audience="End User"; Requirement="Recommended"
       Duration=$null; Level="Beginner"
       Url="https://learn.microsoft.com/en-us/training/modules/explore-microsoft-copilot-business-users/" },

    @{ Title="Draft and refine business content using Microsoft Copilot"
       Product="Microsoft 365 Copilot"; Audience="End User"; Requirement="Required"
       Duration=$null; Level="Beginner"
       Url="https://learn.microsoft.com/en-us/training/modules/draft-refine-business-content/" },

    @{ Title="Research and gather information using Researcher"
       Product="Researcher"; Audience="End User"; Requirement="Recommended"
       Duration=$null; Level="Intermediate"
       Url="https://learn.microsoft.com/en-us/training/modules/draft-refine-business-content/3-research-gather-researcher-agent" },

    @{ Title="Analyze and visualize data using Microsoft Copilot"
       Product="Analyst"; Audience="End User"; Requirement="Recommended"
       Duration=$null; Level="Intermediate"
       Url="https://learn.microsoft.com/en-us/training/modules/analyze-visualize-data-copilot/" },

    @{ Title="Build agents in Copilot Chat (online workshop)"
       Product="Microsoft 365 Agents"; Audience="Maker"; Requirement="Recommended"
       Duration=$null; Level="Beginner"
       Url="https://learn.microsoft.com/en-us/training/modules/agents-copilot-chat/" },

    @{ Title="Agent Builder in Microsoft 365 Copilot"
       Product="Microsoft 365 Agents"; Audience="Maker"; Requirement="Recommended"
       Duration=30; Level="Beginner"
       Url="https://learn.microsoft.com/en-us/microsoft-365/copilot/extensibility/agent-builder" },

    @{ Title="Declarative agents for Microsoft 365 Copilot (overview)"
       Product="Microsoft 365 Agents"; Audience="Maker"; Requirement="Recommended"
       Duration=30; Level="Intermediate"
       Url="https://learn.microsoft.com/en-us/microsoft-365/copilot/extensibility/overview-declarative-agent" },

    @{ Title="Get started with Microsoft Copilot Studio"
       Product="Copilot Studio"; Audience="Maker"; Requirement="Required"
       Duration=$null; Level="Beginner"
       Url="https://learn.microsoft.com/en-us/training/modules/power-virtual-agents-bots/" },

    @{ Title="Create agents in Microsoft Copilot Studio"
       Product="Copilot Studio"; Audience="Maker"; Requirement="Recommended"
       Duration=245; Level="Intermediate"
       Url="https://learn.microsoft.com/en-us/training/paths/create-extend-custom-copilots-microsoft-copilot-studio/" },

    @{ Title="Prepare your organization for Microsoft 365 Copilot"
       Product="Microsoft 365 Copilot"; Audience="Admin"; Requirement="Required"
       Duration=80; Level="Intermediate"
       Url="https://learn.microsoft.com/en-us/training/paths/prepare-your-organization-microsoft-365-copilot/" },

    @{ Title="Prepare security and compliance to support Microsoft 365 Copilot"
       Product="Microsoft 365 Copilot"; Audience="Admin"; Requirement="Required"
       Duration=387; Level="Intermediate"
       Url="https://learn.microsoft.com/en-us/training/paths/prepare-security-compliance-support-microsoft-365-copilot/" },

    @{ Title="Implement Microsoft 365 Copilot"
       Product="Microsoft 365 Copilot"; Audience="Admin"; Requirement="Recommended"
       Duration=51; Level="Intermediate"
       Url="https://learn.microsoft.com/en-us/training/modules/implement-microsoft-365-copilot/" },

    @{ Title="MS-4017: Manage and extend Microsoft 365 Copilot"
       Product="Microsoft 365 Copilot"; Audience="Admin"; Requirement="Optional"
       Duration=480; Level="Intermediate"
       Url="https://learn.microsoft.com/en-us/training/courses/ms-4017" },

    @{ Title="Study guide for Exam AB-900: Microsoft 365 Copilot and Agent Administration Fundamentals"
       Product="Microsoft 365 Copilot"; Audience="Admin"; Requirement="Optional"
       Duration=$null; Level="Intermediate"
       Url="https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/ab-900" },

    @{ Title="Getting Started with GitHub Copilot (GitHub Skills)"
       Product="GitHub Copilot"; Audience="Developer"; Requirement="Required"
       Duration=$null; Level="Beginner"
       Url="https://github.com/skills/getting-started-with-github-copilot" },

    @{ Title="GitHub Copilot documentation"
       Product="GitHub Copilot"; Audience="Developer"; Requirement="Recommended"
       Duration=30; Level="Beginner"
       Url="https://docs.github.com/en/copilot" },

    @{ Title="Get started with AI-assisted development"
       Product="GitHub Copilot"; Audience="Developer"; Requirement="Recommended"
       Duration=$null; Level="Beginner"
       Url="https://learn.microsoft.com/en-us/training/paths/accelerate-app-development-using-github-copilot/" },

    @{ Title="Develop generative AI apps on Microsoft Foundry"
       Product="Microsoft Foundry"; Audience="Developer"; Requirement="Recommended"
       Duration=$null; Level="Intermediate"
       Url="https://learn.microsoft.com/en-us/training/paths/develop-generative-ai-apps/" },

    @{ Title="Get started with generative AI and agents in Azure"
       Product="Microsoft Foundry"; Audience="Developer"; Requirement="Recommended"
       Duration=$null; Level="Beginner"
       Url="https://learn.microsoft.com/en-us/training/modules/get-started-with-generative-ai-and-agents/" },

    @{ Title="Empower your workforce with Microsoft Copilot"
       Product="Microsoft 365 Copilot"; Audience="Leader"; Requirement="Recommended"
       Duration=$null; Level="Beginner"
       Url="https://learn.microsoft.com/en-us/training/paths/empower-workforce-copilot-use-cases/" }
)

# ---------------------------------------------------------------------------
# Connect + verify the list
# ---------------------------------------------------------------------------
if (-not $SkipConnect) {
    Write-Host "Connecting to $($cfg.SiteUrl)" -ForegroundColor Cyan
    Connect-PnPOnline -Url $cfg.SiteUrl -Interactive -ClientId $cfg.ClientId -Tenant $cfg.Tenant
} else {
    Write-Host "Reusing existing PnP connection." -ForegroundColor DarkGray
}

$list = Get-PnPList -Identity $ListTitle -ErrorAction SilentlyContinue
if ($null -eq $list) {
    throw "List '$ListTitle' not found. Run Deploy-CopilotHub.ps1 first."
}

$existing = Get-PnPListItem -List $ListTitle -Fields "Title" |
            ForEach-Object { $_["Title"] }

$added   = 0
$skipped = 0

foreach ($c in $courses) {
    if ($existing -contains $c.Title) {
        Write-Host "  skip  : $($c.Title)" -ForegroundColor DarkGray
        $skipped++
        continue
    }

    $values = @{
        Title              = $c.Title
        CopilotProduct     = $c.Product
        CopilotAudience    = $c.Audience
        CopilotRequirement = $c.Requirement
        CopilotLevel       = $c.Level
        CopilotLearnUrl    = "$($c.Url), $($c.Title)"
    }
    if ($null -ne $c.Duration) { $values.CopilotDurationMinutes = $c.Duration }
    Add-PnPListItem -List $ListTitle -Values $values | Out-Null

    Write-Host "  added : $($c.Title)" -ForegroundColor Green
    $added++
}

Write-Host ""
Write-Host "Done. Added $added, skipped $skipped." -ForegroundColor Cyan
