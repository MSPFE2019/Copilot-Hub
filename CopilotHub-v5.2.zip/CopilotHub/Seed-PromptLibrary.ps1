<#
.SYNOPSIS
  Seeds the Prompt Library list with reviewed starter prompts.

.DESCRIPTION
  Reads SiteUrl from Config.psd1. Idempotent - skips prompts that already exist
  (matched on Title), so edits you make to seeded prompts are preserved.

  Every starter prompt is marked Approved so it appears in the "Approved
  prompts" view shown on the Prompt library page. Review the wording against
  your organization's AI policy before announcing the site.

.EXAMPLE
  .\Seed-PromptLibrary.ps1
#>
[CmdletBinding()]
param(
    [string] $ConfigPath = (Join-Path $PSScriptRoot 'Config.psd1'),
    [string] $ListTitle  = "Prompt Library",
    # When called from Deploy-CopilotHub.ps1 the site connection is already open.
    # Pass -SkipConnect to reuse it and avoid a second browser sign-in prompt.
    [switch] $SkipConnect
)

$ErrorActionPreference = 'Stop'

if (-not (Test-Path $ConfigPath)) {
    throw "Config file not found: $ConfigPath"
}
$cfg = Import-PowerShellDataFile -Path $ConfigPath

foreach ($k in 'SiteUrl') {
    if ([string]::IsNullOrWhiteSpace($cfg.$k)) {
        throw "Config.psd1 is missing required value: $k"
    }
}
if (-not $SkipConnect) {
    foreach ($k in 'Tenant','ClientId') {
        if ([string]::IsNullOrWhiteSpace($cfg.$k)) {
            throw "Config.psd1 is missing required value: $k"
        }
    }
}

# ---------------------------------------------------------------------------
# Starter prompts
#   Product / App / Audience values must match the choices defined for the
#   CopilotProduct, CopilotApp, and CopilotAudience site columns.
# ---------------------------------------------------------------------------
$prompts = @(
    @{ Title    = "Catch up on a long email thread"
       Prompt   = "Summarize this email thread in five bullet points. List any decisions that were made and any questions that are still waiting on me."
       When     = "Open the thread in Outlook and ask Copilot there, so it works from the messages in front of you."
       Product  = "Microsoft 365 Copilot"; App = "Outlook"; Audience = "End User" },

    @{ Title    = "Recap a meeting"
       Prompt   = "Recap this meeting: the key decisions, action items with owners and due dates, and any questions that were left open."
       When     = "Works on Teams meetings that were transcribed or recorded."
       Product  = "Microsoft 365 Copilot"; App = "Teams"; Audience = "End User" },

    @{ Title    = "Prepare for a meeting"
       Prompt   = "Help me prepare for my meeting with [name] on [date]. Summarize our recent emails, chats, and shared files, and suggest three talking points."
       When     = "Draws on your work email, chats, and files, so it needs a Microsoft 365 Copilot license."
       Product  = "Microsoft 365 Copilot"; App = "Copilot Chat"; Audience = "End User" },

    @{ Title    = "Turn notes into a first draft"
       Prompt   = "Using the notes below, draft a one-page project update for leadership with sections for progress, risks, and next steps. Keep the tone concise and professional.`n`n[paste your notes]"
       When     = "Start in a new Word document. Review and edit the draft before you share it."
       Product  = "Microsoft 365 Copilot"; App = "Word"; Audience = "End User" },

    @{ Title    = "Find the trends in a table"
       Prompt   = "Show the three biggest changes month over month in this table, and add a chart that highlights them."
       When     = "Works best when the data is formatted as an Excel table with clear column headers."
       Product  = "Microsoft 365 Copilot"; App = "Excel"; Audience = "End User" },

    @{ Title    = "Build a presentation from a document"
       Prompt   = "Create a ten-slide presentation from [file], with an agenda slide, one key message per slide, and speaker notes."
       When     = "Choose the source file when PowerPoint asks, then refine the slides and check every fact."
       Product  = "Microsoft 365 Copilot"; App = "PowerPoint"; Audience = "End User" },

    @{ Title    = "Explain a topic simply"
       Prompt   = "Explain [topic] in plain language for someone new to it. Then give me three questions I can use to check my understanding."
       When     = "A good first prompt for anyone new to Copilot. Follow your organization's AI policy about what information you include."
       Product  = "Copilot Chat"; App = "Copilot Chat"; Audience = "End User" },

    @{ Title    = "Rewrite for a different audience"
       Prompt   = "Rewrite the text below for a customer audience: shorter sentences, no internal jargon, and a friendly, professional tone.`n`n[paste your text]"
       When     = "Useful for emails, announcements, and help articles."
       Product  = "Copilot Chat"; App = "Copilot Chat"; Audience = "End User" },

    @{ Title    = "Research briefing"
       Prompt   = "Research [topic] using our internal documents and reliable web sources. Produce a briefing with a summary, key findings with citations, open questions, and recommended next steps."
       When     = "Researcher may ask clarifying questions before it starts. Check the sources it cites before relying on the briefing."
       Product  = "Researcher"; App = "Researcher"; Audience = "End User" },

    @{ Title    = "Analyze a dataset"
       Prompt   = "Analyze the attached data. Identify the main drivers of change, show the results as charts, and explain your method and any assumptions."
       When     = "Attach an Excel or CSV file. Review Analyst's reasoning and results before you share them."
       Product  = "Analyst"; App = "Analyst"; Audience = "End User" },

    @{ Title    = "Describe an agent to build"
       Prompt   = "Create an agent that answers questions about our travel policy using the Travel Policy SharePoint site. It should quote the relevant policy section, keep answers short, and suggest contacting HR when it isn't sure."
       When     = "Paste into Agent Builder, point it at your own knowledge source, and test it before you share it."
       Product  = "Microsoft 365 Agents"; App = "Agent Builder"; Audience = "Maker" },

    @{ Title    = "Understand and test code"
       Prompt   = "Explain what this function does, list the edge cases it doesn't handle, and write unit tests for them."
       When     = "Ask in GitHub Copilot Chat in your code editor with the file open. Review generated tests before you commit them."
       Product  = "GitHub Copilot"; App = "Code editor"; Audience = "Developer" }
)

# ---------------------------------------------------------------------------
# Connect + verify the list
# ---------------------------------------------------------------------------
if (-not $SkipConnect) {
    Write-Host "Connecting to $($cfg.SiteUrl)" -ForegroundColor Cyan
    Connect-PnPOnline -Url $cfg.SiteUrl -Interactive -ClientId $cfg.ClientId -Tenant $cfg.Tenant
} else {
    Write-Host "Reusing existing PnP connection." -ForegroundColor DarkGray
}

$list = Get-PnPList -Identity $ListTitle -ErrorAction SilentlyContinue
if ($null -eq $list) {
    throw "List '$ListTitle' not found. Run Deploy-CopilotHub.ps1 first."
}

$existing = @(Get-PnPListItem -List $ListTitle -Fields "Title" | ForEach-Object { $_["Title"] })

$added   = 0
$skipped = 0

foreach ($p in $prompts) {
    if ($existing -contains $p.Title) {
        Write-Host "  skip  : $($p.Title)" -ForegroundColor DarkGray
        $skipped++
        continue
    }

    Add-PnPListItem -List $ListTitle -Values @{
        Title                = $p.Title
        CopilotPromptText    = $p.Prompt
        CopilotDescription   = $p.When
        CopilotProduct       = $p.Product
        CopilotApp           = $p.App
        CopilotAudience      = $p.Audience
        CopilotApprovalState = "Approved"
    } | Out-Null

    Write-Host "  added : $($p.Title)" -ForegroundColor Green
    $added++
}

Write-Host ""
Write-Host "Done. Added $added, skipped $skipped." -ForegroundColor Cyan
