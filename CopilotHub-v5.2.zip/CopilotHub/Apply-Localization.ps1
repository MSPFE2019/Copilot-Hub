<#
.SYNOPSIS
  Applies a localization content pack (navigation labels, page titles, site-column
  display names, list titles) to an already-deployed Copilot Hub site.

.DESCRIPTION
  Reads SiteUrl/Tenant/ClientId from Config.psd1 (same file Deploy-CopilotHub.ps1
  uses) and a locale content pack from .\localization\<Locale>\content.json.

  Run Deploy-CopilotHub.ps1 first. This script only renames existing navigation
  nodes, pages, site columns, and lists to their localized labels - it never
  creates, deletes, or recreates content. It is idempotent: safe to re-run, and
  safe to re-run against an already-localized site (it simply re-applies the
  same values).

  See .\localization\README.md for the content-pack format, supported locales,
  and known limitations (list item data and full page bodies beyond the three
  project-authored pages are not localized).

.PARAMETER ConfigPath
  Path to Config.psd1. Defaults to .\Config.psd1 next to this script.

.PARAMETER Locale
  One of: es-ES, fr-FR, de-DE.

.PARAMETER SkipConnect
  When called from Deploy-CopilotHub.ps1 (or another script) that already holds
  an open PnP connection, pass this to reuse it instead of prompting to sign in
  again.

.EXAMPLE
  .\Apply-Localization.ps1 -Locale es-ES

.EXAMPLE
  .\Apply-Localization.ps1 -ConfigPath .\Config.Prod.psd1 -Locale de-DE
#>
[CmdletBinding()]
param(
    [string] $ConfigPath = (Join-Path $PSScriptRoot 'Config.psd1'),

    [Parameter(Mandatory)]
    [ValidateSet('es-ES', 'fr-FR', 'de-DE')]
    [string] $Locale,

    [switch] $SkipConnect
)

$ErrorActionPreference = 'Stop'

function Write-Step([string] $Message) {
    Write-Host ""
    Write-Host "==> $Message" -ForegroundColor Cyan
}

function Write-Item([string] $Message) {
    Write-Host "    $Message"
}

function Write-Warn([string] $Message) {
    Write-Host "    $Message" -ForegroundColor Yellow
}

if (-not (Test-Path $ConfigPath)) {
    throw "Config file not found: $ConfigPath"
}
$cfg = Import-PowerShellDataFile -Path $ConfigPath

foreach ($k in 'SiteUrl') {
    if ([string]::IsNullOrWhiteSpace($cfg.$k)) {
        throw "Config.psd1 is missing required value: $k"
    }
}
if (-not $SkipConnect) {
    foreach ($k in 'Tenant', 'ClientId') {
        if ([string]::IsNullOrWhiteSpace($cfg.$k)) {
            throw "Config.psd1 is missing required value: $k"
        }
    }
}

$packPath = Join-Path $PSScriptRoot "localization\$Locale\content.json"
if (-not (Test-Path $packPath)) {
    throw "Localization pack not found: $packPath. Supported locales: es-ES, fr-FR, de-DE."
}
$pack = Get-Content -Path $packPath -Raw -Encoding UTF8 | ConvertFrom-Json
Write-Item "Loaded localization pack: $Locale ($($pack.language))"

# Packs are written against the template, so they contain template tokens.
# Resolve them to the live values before matching or writing anything, so a
# key like "Copilot at {parameter:CompanyName}" matches "Copilot at Contoso"
# and localized links never contain a literal "{site}".
function Resolve-Tokens([string] $Text) {
    if ([string]::IsNullOrEmpty($Text)) { return $Text }
    return $Text.Replace('{parameter:CompanyName}', $cfg.CompanyName).Replace('{site}', $cfg.SiteUrl.TrimEnd('/'))
}

if (-not $SkipConnect) {
    Write-Host "Connecting to $($cfg.SiteUrl)" -ForegroundColor Cyan
    Connect-PnPOnline -Url $cfg.SiteUrl -Interactive -ClientId $cfg.ClientId -Tenant $cfg.Tenant
} else {
    Write-Host "Reusing existing PnP connection." -ForegroundColor DarkGray
}

$applied = 0
$missing = 0

# ---------------------------------------------------------------------------
# Navigation
#   A communication site's own menu and its hub menu live in different node
#   collections (QuickLaunch / TopNavigationBar), so walk both. Nodes are
#   renamed through CSOM because PnP.PowerShell 1.12 has no
#   Set-PnPNavigationNode cmdlet.
# ---------------------------------------------------------------------------
Write-Step "Localizing navigation ($Locale)"
$navMap = @{}
$pack.navigation.PSObject.Properties | ForEach-Object { $navMap[(Resolve-Tokens $_.Name)] = (Resolve-Tokens $_.Value) }
$matchedNav = @{}
$ctx = Get-PnPContext

function Set-NavNodeTitleRecursive($nodes) {
    foreach ($node in $nodes) {
        if ($navMap.ContainsKey($node.Title)) {
            $original = $node.Title
            $localizedTitle = $navMap[$original]
            if ($original -ne $localizedTitle) {
                $node.Title = $localizedTitle
                $node.Update()
                $ctx.ExecuteQuery()
                Write-Item "nav   : '$original' -> '$localizedTitle'"
                $script:applied++
            }
            $matchedNav[$original] = $true
        } elseif ($navMap.Values -contains $node.Title) {
            $matchedNav[($navMap.GetEnumerator() | Where-Object { $_.Value -eq $node.Title } | Select-Object -First 1).Key] = $true
        }
        $ctx.Load($node.Children)
        $ctx.ExecuteQuery()
        if ($node.Children.Count -gt 0) {
            Set-NavNodeTitleRecursive -nodes $node.Children
        }
    }
}

foreach ($location in 'QuickLaunch', 'TopNavigationBar') {
    $nodes = @(Get-PnPNavigationNode -Location $location -ErrorAction SilentlyContinue)
    if ($nodes.Count -gt 0) {
        Set-NavNodeTitleRecursive -nodes $nodes
    }
}
foreach ($key in $navMap.Keys) {
    if (-not $matchedNav.ContainsKey($key)) {
        Write-Warn "no match: navigation node '$key' not found on the site (skipped)"
        $missing++
    }
}

# ---------------------------------------------------------------------------
# Page titles and intro text
# ---------------------------------------------------------------------------
Write-Step "Localizing page titles ($Locale)"
foreach ($pageEntry in $pack.pages.PSObject.Properties) {
    $pageName = Resolve-Tokens $pageEntry.Name
    $pageInfo = $pageEntry.Value
    $page = Get-PnPPage -Identity $pageName -ErrorAction SilentlyContinue
    if ($null -eq $page) {
        Write-Warn "no match: page '$pageName' not found on the site (skipped)"
        $missing++
        continue
    }
    $changed = $false
    $localizedPageTitle = Resolve-Tokens $pageInfo.title
    if ($localizedPageTitle -and $page.PageTitle -ne $localizedPageTitle) {
        Set-PnPPage -Identity $pageName -Title $localizedPageTitle | Out-Null
        Write-Item "page  : '$pageName' title -> '$localizedPageTitle'"
        $applied++
        $changed = $true
    }
    if ($pageInfo.introText) {
        $textPart = Get-PnPPageComponent -Page $pageName |
                    Where-Object { $_.GetType().Name -eq 'PageText' } |
                    Select-Object -First 1
        if ($textPart) {
            Set-PnPPageTextPart -Page $pageName -InstanceId $textPart.InstanceId -Text (Resolve-Tokens $pageInfo.introText) | Out-Null
            Write-Item "page  : '$pageName' intro text localized"
            $applied++
            $changed = $true
        } else {
            Write-Warn "no match: page '$pageName' has no text web part to localize (skipped)"
            $missing++
        }
    }
    if ($changed) {
        Set-PnPPage -Identity $pageName -Publish | Out-Null
    }
}

# ---------------------------------------------------------------------------
# Site columns
# ---------------------------------------------------------------------------
Write-Step "Localizing site columns ($Locale)"
foreach ($colEntry in $pack.siteColumns.PSObject.Properties) {
    $internalName = $colEntry.Name
    $localizedName = $colEntry.Value
    $field = Get-PnPField -Identity $internalName -ErrorAction SilentlyContinue
    if ($null -eq $field) {
        Write-Warn "no match: site column '$internalName' not found on the site (skipped)"
        $missing++
        continue
    }
    if ($field.Title -ne $localizedName) {
        Set-PnPField -Identity $internalName -Values @{ Title = $localizedName } | Out-Null
        Write-Item "column: '$internalName' display name -> '$localizedName'"
        $applied++
    }
}

# ---------------------------------------------------------------------------
# Lists
# ---------------------------------------------------------------------------
Write-Step "Localizing list titles ($Locale)"
foreach ($listEntry in $pack.lists.PSObject.Properties) {
    $englishTitle = $listEntry.Name
    $localizedTitle = $listEntry.Value
    $list = Get-PnPList -Identity $englishTitle -ErrorAction SilentlyContinue
    if ($null -eq $list) {
        Write-Warn "no match: list '$englishTitle' not found on the site (skipped)"
        $missing++
        continue
    }
    if ($list.Title -ne $localizedTitle) {
        Set-PnPList -Identity $englishTitle -Title $localizedTitle | Out-Null
        Write-Item "list  : '$englishTitle' -> '$localizedTitle'"
        $applied++
    }
}

Write-Host ""
Write-Host "Done. Applied $applied change(s), $missing pack key(s) had no matching site object." -ForegroundColor Cyan
if ($missing -gt 0) {
    Write-Warn "Review the 'no match' lines above - they usually mean the base template changed since this pack was written."
}
