# Copilot Hub v5.2.7

This deployment-only patch preserves all v5.2.6 template content and updates script behavior for reliability across reruns and sovereign-cloud tenants.

## Changes

- Ensured Site Collection Admin access for both configured owner and deploying user before template apply, including existing-site reruns.
- Added sovereign-cloud-aware deployment settings: optional `AdminUrl` and `AzureEnvironment` in `Config.psd1`, and `-AzureEnvironment` usage on all `Connect-PnPOnline` calls.
- Updated offline validator assertions to enforce the new deployment guardrails and v5.2.7 provenance.
- Kept `template.pnp` and seeded content unchanged from v5.2.6.

## Compatibility notes

- No SharePoint page, list, web-part, or localization content changes were made in this release.
- The deleted-site lookup fix and explicit purge approval guard remain in place.
- Reapplying the template retains existing overwrite and page-publishing behavior. Back up customizations and test in a non-production site before deployment.
