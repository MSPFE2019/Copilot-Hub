
# 🤖 Microsoft Copilot Guided Learning

> **Last updated:** July 2026  ·  Source: [Microsoft Learn – M365 Copilot Training](https://learn.microsoft.com/en-us/training/browse/?products=m365&terms=Copilot)

**How to use:** Click any title to open the training on Microsoft Learn. Look for 🛤️ **Learning Path** (multi-module series), 📦 **Module** (focused topic), or 🎓 **Course** (instructor-led). Items are sorted Beginner → Intermediate → Advanced within each track.

**Tracks:** [⚙️ Tech Track](#️-tech-track) · [👤 User Track](#-user-track) · [🛡️ Admin & IT Track](#️-admin--it-track)

---

## ⚙️ Tech Track

> For developers, Power Platform makers, and architects: build declarative agents, API plugins, Copilot Studio solutions, and connectors to extend Microsoft 365 Copilot.

### 🔹 Beginner

#### [Add custom knowledge to declarative agents using Copilot connectors and Visual Studio Code](https://learn.microsoft.com/training/modules/copilot-declarative-agent-graph-connector-vsc/)

Build a declarative agent for Microsoft 365 Copilot optimized for a specific scenario. Your agent accesses data stored outside of Microsoft 365 by using a Copilot connector.

`📦 Module · 27m` | **Level:** Beginner | **Tags:** Microsoft Copilot, Microsoft Graph

#### [Build a foundation to build AI agents and extend Microsoft 365 Copilot](https://learn.microsoft.com/training/courses/ms-4014/)

Curious about building AI agents but unsure where to start? MS-4014 offers a clear and practical introduction to the tools and techniques for building AI agents and extending Microsoft 365 Copilot.

`🎓 Course` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot, Microsoft Copilot, Microsoft Copilot Studio

#### [Build a foundation to build AI agents and extend Microsoft 365 Copilot](https://learn.microsoft.com/training/paths/build-foundation-extend-microsoft-365-copilot/)

Prepare to build AI agents and extend Microsoft 365 Copilot using Copilot Studio, Microsoft Foundry, Microsoft 365 Agents Toolkit, and more. Explore agent use cases, development paths, tools, and resources.

`🛤️ Learning Path · 1h 44m` | **Level:** Beginner | **Tags:** Azure, Microsoft 365 Copilot, Microsoft Copilot Studio

#### [Build and manage an agent](https://learn.microsoft.com/training/modules/build-manage-no-code-copilot-agent-sharepoint/)

This module guides you through the foundational concepts and practical steps required to create, test, and manage agents in Microsoft 365 Copilot Chat and SharePoint.

`📦 Module · 1h 32m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot, Microsoft 365 Copilot Chat

#### [Build your first action for declarative agents with API plugin by using Visual Studio Code](https://learn.microsoft.com/training/modules/copilot-declarative-agent-action-api-plugin-vsc/)

Build a declarative agent for Microsoft 365 Copilot optimized for a specific scenario. Bring actions to your agent with API plugins to access external data in real-time.

`📦 Module · 28m` | **Level:** Beginner | **Tags:** Microsoft Copilot

#### [Choose the best Microsoft 365 Copilot extensibility path for your scenario](https://learn.microsoft.com/training/modules/choose-microsoft-365-copilot-extensibility-path/)

Explore development options for extending Microsoft 365 Copilot with custom data, logic, and actions. Determine the best approach for your scenario.

`📦 Module · 29m` | **Level:** Beginner | **Tags:** Azure, Microsoft 365 Copilot, Microsoft 365 Copilot Chat

#### [Connect Microsoft 365 Copilot to your external data with message extension plugins (.NET)](https://learn.microsoft.com/training/modules/copilot-message-extension-plugins/)

Learn how to build Microsoft 365 Copilot message extension plugins to connect it to external data sources and extend its capabilities using .NET and Visual Studio.

`📦 Module · 1h 3m` | **Level:** Beginner | **Tags:** Microsoft Copilot, Microsoft Teams

#### [Connect Microsoft 365 Copilot to your external data with message extension plugins (TypeScript)](https://learn.microsoft.com/training/modules/copilot-message-extension-plugins-typescript/)

Learn how to build Microsoft 365 Copilot message extension plugins to connect it to external data sources and extend its capabilities with TypeScript and Visual Studio Code.

`📦 Module · 1h 3m` | **Level:** Beginner | **Tags:** Microsoft Copilot, Microsoft Teams

#### [Drive business value with AI solutions](https://learn.microsoft.com/training/paths/drive-value-generative-ai-solutions/)

Discover how Copilot and Azure AI can transform work across your organization by enhancing productivity and enabling smarter decisions.

`🛤️ Learning Path · 1h 8m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot, Microsoft Copilot, Azure

#### [Drive business value with Microsoft Copilot solutions](https://learn.microsoft.com/training/modules/business-value-microsoft-copilot-solutions/)

Understand how Microsoft Copilot solutions can drive business value by enhancing productivity, improving decision-making, and fostering innovation.

`📦 Module · 38m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot, Microsoft Copilot, Microsoft Copilot Studio

#### [Explore role-based AI agent skills for business users](https://learn.microsoft.com/training/paths/explore-role-based-ai-agent-skills-business-users/)

Explore how role-based AI agents in Microsoft 365 Copilot can help business professionals work faster by supporting common tasks such as research, analysis, and executive communication.

`🛤️ Learning Path · 1h 40m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot, Microsoft 365 Copilot Chat

#### [Extend and optimize Microsoft 365 Copilot in your organization](https://learn.microsoft.com/training/modules/extend-optimize-copilot-m365/)

Learn about the fourth phase—Extend & Optimize—in the user enablement framework for Microsoft 365 Copilot adoption.

`📦 Module · 18m` | **Level:** Beginner | **Tags:** Microsoft Copilot

#### [Extend declarative agents for Microsoft 365 Copilot with API plugins using Visual Studio Code](https://learn.microsoft.com/training/paths/copilot-microsoft-365-declarative-agents-api-plugins-visual-studio-code/)

Multi-part series teaching the basic concepts of extending declarative agents with actions using API plugins to access external data in real-time.

`🛤️ Learning Path · 1h 23m` | **Level:** Beginner | **Tags:** Microsoft Copilot

#### [Extend Microsoft 365 Copilot in .NET](https://learn.microsoft.com/training/paths/copilot-m365-extensibility/)

Multi-part series teaching basic concepts of extending Copilot for Microsoft 365 using .NET, including message extensions and connectors.

`🛤️ Learning Path · 2h 6m` | **Level:** Beginner | **Tags:** Microsoft Copilot, Microsoft Graph

#### [Extend Microsoft 365 Copilot in TypeScript](https://learn.microsoft.com/training/paths/copilot-m365-extensibility-typescript/)

Multi-part series teaching basic concepts of extending Copilot for Microsoft 365 using TypeScript, including message extensions and connectors.

`🛤️ Learning Path · 2h 1m` | **Level:** Beginner | **Tags:** Microsoft Copilot, Microsoft Graph

#### [Extend Microsoft 365 Copilot with declarative agents using Visual Studio Code](https://learn.microsoft.com/training/paths/copilot-microsoft-365-declarative-agents-visual-studio-code/)

Multi-part series teaching how to build and deploy declarative agents for Microsoft 365 Copilot using Visual Studio Code—covering knowledge, tools, actions, and publishing.

`🛤️ Learning Path · 5h 34m` | **Level:** Beginner | **Tags:** Microsoft Copilot, Microsoft Graph

#### [Get started with agents](https://learn.microsoft.com/training/modules/get-started-no-code-copilot-agents-sharepoint/)

Examines how agents act as AI-powered assistants embedded within SharePoint and Microsoft Copilot Chat—providing real-time support, automating processes, and helping users find information.

`📦 Module · 35m` | **Level:** Beginner | **Tags:** Office 365

#### [Get started with Microsoft 365 Copilot extensibility](https://learn.microsoft.com/training/modules/copilot-extensibility-intro/)

Learn what Microsoft 365 Copilot is and why you should consider extending it. Covers the different options available for extensibility.

`📦 Module · 13m` | **Level:** Beginner | **Tags:** Microsoft Copilot, Microsoft Graph

#### [Integrate external content with Microsoft 365 Copilot using Copilot connectors (.NET)](https://learn.microsoft.com/training/modules/copilot-graph-connectors/)

Build Copilot connectors to import external content to Microsoft 365 using .NET on any platform.

`📦 Module · 50m` | **Level:** Beginner | **Tags:** Microsoft Copilot, Microsoft Graph

#### [Integrate external content with Microsoft 365 Copilot using Copilot connectors (TypeScript)](https://learn.microsoft.com/training/modules/copilot-graph-connectors-typescript/)

Build Copilot connectors using TypeScript to import external content to Microsoft 365.

`📦 Module · 45m` | **Level:** Beginner | **Tags:** Microsoft Copilot, Microsoft Graph

#### [Optimize and extend Microsoft 365 Copilot](https://learn.microsoft.com/training/modules/optimize-and-extend-microsoft-365-copilot/)

Explores comprehensive best practices for Microsoft 365 Copilot and key extension methods, ensuring you harness the full potential and versatility of Copilot's functionality.

`📦 Module · 30m` | **Level:** Beginner | **Tags:** Microsoft Copilot, Microsoft 365 Apps

#### [Transform business workflows with generative AI](https://learn.microsoft.com/training/paths/transform-business-workflows-with-ai/)

Enables learners to use Microsoft 365 Copilot and generative AI to simplify tasks, boost productivity, and make smarter decisions through practical, no-code scenarios.

`🛤️ Learning Path · 4h 30m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot, Office 365

#### [Transform business workflows with generative AI](https://learn.microsoft.com/training/courses/ab-730t00/)

Instructor-led course on applying generative AI to streamline daily tasks, enhance decision-making, and drive business outcomes with Microsoft 365 Copilot.

`🎓 Course` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Understand AI agents and prompting](https://learn.microsoft.com/training/modules/understand-ai-agents-prompting/)

Learn about what AI agents are and when to use them in everyday tasks. Understand how to optimize your prompts to get the best possible results from Copilot.

`📦 Module · 36m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Unlock the power of Microsoft agents](https://learn.microsoft.com/training/modules/unlock-power-microsoft-agents/)

Learn to use Microsoft 365 Copilot AI agents—understanding types, benefits, workflows, setup, and custom agent creation.

`📦 Module · 50m` | **Level:** Beginner | **Tags:** Microsoft Copilot, OneDrive

#### [Unlock the power of Microsoft agents (1-hour)](https://learn.microsoft.com/training/courses/unlock-power-microsoft-agents-1-hour/)

Learn how agents embedded in SharePoint and Microsoft 365 Copilot Chat provide real-time support, automate tasks, analyze data, and offer personalized assistance.

`🎓 Course · 1h` | **Level:** Beginner | **Tags:** Microsoft Copilot, OneDrive

#### [Unlock the power of Microsoft agents (3-hour)](https://learn.microsoft.com/training/courses/unlock-power-microsoft-agents-3-hour/)

Extended instructor-led version: learn how agents in SharePoint and Microsoft 365 Copilot Chat provide real-time support, automate tasks, analyze data, and offer personalized assistance.

`🎓 Course · 3h` | **Level:** Beginner | **Tags:** Microsoft Copilot, OneDrive

### 🔹 Intermediate

#### [Authenticate your API plugin for declarative agents with secured APIs](https://learn.microsoft.com/training/modules/copilot-declarative-agent-api-plugin-auth/)

Learn about the two common ways APIs are secured (API key and OAuth2) and how to integrate with secured APIs when building actions for declarative agents.

`📦 Module · 29m` | **Level:** Intermediate | **Tags:** Microsoft Copilot

#### [Build secure agents for public sector services](https://learn.microsoft.com/training/modules/build-secure-agents-public-sector-services/)

Public sector organizations use agentic AI, Copilot, and Azure AI Foundry to automate complex workflows, improve citizen service delivery, and govern AI responsibly.

`📦 Module · 1h 1m` | **Level:** Intermediate | **Tags:** Microsoft Copilot

#### [Build your first declarative agent for Microsoft 365 Copilot by using Copilot Studio](https://learn.microsoft.com/training/modules/build-your-first-agent-microsoft-365-copilot-use-copilot-studio/)

Define an agent to extend Microsoft 365 Copilot tailored to a specific scenario. Your declarative agent provides relevant and accurate responses using custom knowledge.

`📦 Module · 1h 7m` | **Level:** Intermediate | **Tags:** Microsoft 365 Copilot, Microsoft Copilot, Microsoft Copilot Studio

#### [Challenge project – Build a declarative agent to chat with your data](https://learn.microsoft.com/training/modules/copilot-declarative-agent-challenge-chat-with-data/)

Demonstrate your ability to create a declarative agent for Microsoft 365 Copilot that accesses data from an external API.

`📦 Module · 1h 33m` | **Level:** Intermediate | **Tags:** Microsoft 365 Copilot

#### [Challenge project – Build a declarative agent to chat with your docs](https://learn.microsoft.com/training/modules/copilot-declarative-agent-challenge-chat-with-docs/)

Demonstrate your ability to create a declarative agent for Microsoft 365 Copilot that can answer questions using information from documents.

`📦 Module · 53m` | **Level:** Intermediate | **Tags:** Microsoft Copilot, Microsoft 365 Copilot

#### [Design and build integrated AI agent solutions in Copilot Studio](https://learn.microsoft.com/training/courses/ab-620t00/)

Learn how to design, build, and manage production-ready AI agent solutions using Microsoft Copilot Studio with integration across Microsoft 365 and Azure. *(Available 7/31/2026)*

`🎓 Course` | **Level:** Intermediate | **Tags:** Azure, Microsoft 365 Copilot, Microsoft Copilot Studio

#### [Extend declarative agents with connector tools in Copilot Studio](https://learn.microsoft.com/training/modules/extend-declarative-agents-connector-actions-copilot-studio/)

Connect your declarative agent to external services and data using connector tools. Configure out-of-the-box connectors and add them to declarative agents that extend Microsoft 365 Copilot.

`📦 Module · 38m` | **Level:** Intermediate | **Tags:** Microsoft 365 Copilot, Microsoft Copilot, Microsoft Copilot Studio

#### [Extend declarative agents with prompt tools in Copilot Studio](https://learn.microsoft.com/training/modules/extend-declarative-agents-prompt-actions-copilot-studio/)

Customize your declarative agent's generative responses by extending your agent with prompt tools. Craft custom prompts, test them against the LLM, and add prompt tools to your agent.

`📦 Module · 35m` | **Level:** Intermediate | **Tags:** Microsoft 365 Copilot, Microsoft Copilot, Microsoft Copilot Studio

#### [Extend Microsoft 365 Copilot in Copilot Studio](https://learn.microsoft.com/training/courses/ms-4022/)

Instructor-led: unlock the full potential of Microsoft 365 Copilot by building intelligent declarative agents using Microsoft Copilot Studio with custom knowledge and actions.

`🎓 Course` | **Level:** Intermediate | **Tags:** Microsoft 365 Copilot, Microsoft Copilot, Microsoft Copilot Studio

#### [Extend Microsoft 365 Copilot in Copilot Studio](https://learn.microsoft.com/training/paths/extend-microsoft-365-copilot-studio/)

Build agents that extend Microsoft 365 Copilot with additional knowledge and capabilities. Use Copilot Studio to build declarative agents, add knowledge, add tools, and publish them.

`🛤️ Learning Path · 3h 2m` | **Level:** Intermediate | **Tags:** Microsoft 365 Copilot, Microsoft Copilot, Microsoft Copilot Studio

#### [Integrate your agent with Microsoft 365](https://learn.microsoft.com/training/modules/integrate-foundry-agent-with-m365/)

Learn how to publish Microsoft Foundry agents to Microsoft Teams and Microsoft 365 Copilot, access workplace data, and test your integrated agents.

`📦 Module · 1h 14m` | **Level:** Intermediate | **Tags:** Azure, Microsoft Foundry

#### [Introduction to tools for declarative agents in Copilot Studio](https://learn.microsoft.com/training/modules/introduction-copilot-studio-actions/)

Explore how to create and configure tools in Copilot Studio to connect your declarative agent to external data sources and customize generative responses.

`📦 Module · 23m` | **Level:** Intermediate | **Tags:** Microsoft 365 Copilot, Microsoft Copilot, Microsoft Copilot Studio

#### [Manage and extend Microsoft 365 Copilot](https://learn.microsoft.com/training/courses/ms-4017/)

MS-4017 examines how administrators can manage and extend Microsoft 365 Copilot to meet business needs. Covers Copilot management, extensibility options, governance, and deployment.

`🎓 Course` | **Level:** Intermediate | **Tags:** Microsoft 365

#### [Scale how you work by creating AI agents](https://learn.microsoft.com/training/modules/scale-work-creating-ai-agents/)

Explores how business users with no technical experience can create AI agents in Microsoft 365 Copilot Chat to increase productivity and streamline workflows.

`📦 Module · 20m` | **Level:** Intermediate | **Tags:** Microsoft 365 Copilot, Microsoft 365 Copilot Chat

#### [Use Adaptive Cards to show data in API plugins for declarative agents](https://learn.microsoft.com/training/modules/copilot-declarative-agent-action-api-plugin-adaptive-cards-vsc/)

Learn how to enhance the user experience of declarative agents by using Adaptive Cards to render API data visually with custom templates.

`📦 Module · 16m` | **Level:** Intermediate | **Tags:** Microsoft Copilot

### 🔹 Advanced

#### [Analyze requirements for AI-powered business solutions](https://learn.microsoft.com/training/modules/analyze-requirements-ai-powered-business-solutions/)

Learn to analyze, design, and implement AI-powered business solutions using agents, generative AI, and Microsoft Copilot for productivity.

`📦 Module · 25m` | **Level:** Advanced | **Tags:** Microsoft 365 Copilot, Microsoft Power Platform

#### [Architect AI solutions for business productivity](https://learn.microsoft.com/training/paths/architect-agentic-ai-business-solutions/)

Learn how to design AI-powered business solutions using agents, generative AI, and Microsoft Copilot to enhance productivity and efficiency at enterprise scale.

`🛤️ Learning Path · 11h 24m` | **Level:** Advanced | **Tags:** Microsoft 365 Copilot, Microsoft Power Platform

#### [Design AI agents for business solutions](https://learn.microsoft.com/training/modules/design-ai-agents-business-solutions/)

Learn to design AI agents tailored to business needs using Dynamics 365 and Copilot. Explore Responsible AI, custom connectors, and integration strategies.

`📦 Module · 2h 41m` | **Level:** Advanced | **Tags:** Microsoft 365 Copilot, Microsoft Power Platform

---

## 👤 User Track

> For M365 end users and business professionals: get started with Copilot, master prompting, boost productivity in Word/Excel/Teams/Outlook, and explore role-based use cases.

### 🔹 Beginner

#### [Analyze and visualize data using Microsoft 365 Copilot](https://learn.microsoft.com/training/modules/analyze-visualize-data-copilot/)

Learn how to use Microsoft 365 Copilot to analyze and visualize your data, turning raw information into actionable insights.

`📦 Module · 27m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Ask questions and analyze content with Microsoft 365 Copilot](https://learn.microsoft.com/training/modules/ask-analyze-content-with-microsoft-copilot-microsoft-365/)

Learn how to use Microsoft 365 Copilot to ask questions about and analyze your existing content, extracting insights and answering queries efficiently.

`📦 Module · 38m` | **Level:** Beginner | **Tags:** Microsoft Copilot, Business User

#### [Build effective presentations with AI](https://learn.microsoft.com/training/modules/build-effective-presentations-with-ai/)

Discover how to use AI tools including Microsoft 365 Copilot to design and build compelling, professional presentations faster.

`📦 Module · ~30m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Conduct structured interviews using Microsoft Teams and Copilot](https://learn.microsoft.com/training/modules/conduct-structured-interviews-microsoft-teams-copilot/)

Explore how to leverage Microsoft Teams and Copilot to structure, conduct, and follow up on interviews more efficiently.

`📦 Module · ~30m` | **Level:** Beginner | **Tags:** Microsoft Teams, Microsoft 365 Copilot

#### [Copilot for all the ways you work](https://learn.microsoft.com/training/paths/copilot-all-ways-work/)

A comprehensive learning path covering how to use Microsoft 365 Copilot across everyday work scenarios—from email and meetings to documents and data.

`🛤️ Learning Path` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Copilot Immersion Experience](https://learn.microsoft.com/training/paths/copilot-immersion-experience/)

Hands-on immersion experience introducing Microsoft 365 Copilot with practical scenarios and exercises across the M365 app suite.

`🛤️ Learning Path` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Craft effective prompts for Microsoft 365 Copilot](https://learn.microsoft.com/training/paths/craft-effective-prompts-copilot-microsoft-365/)

Learn how to write clear, effective prompts to get the best results from Microsoft 365 Copilot in your daily work tasks.

`🛤️ Learning Path · 2h 10m` | **Level:** Beginner | **Tags:** Microsoft Copilot, Business User

#### [Create and draft with Microsoft 365 Copilot](https://learn.microsoft.com/training/modules/create-draft-content-with-microsoft-copilot-microsoft-365/)

Learn how to use Microsoft 365 Copilot to create and draft various types of content, from emails and documents to presentations and messages.

`📦 Module · 27m` | **Level:** Beginner | **Tags:** Microsoft Copilot, Business User

#### [Define the role you want Microsoft 365 Copilot to play in your business workflow](https://learn.microsoft.com/training/modules/define-role-microsoft-365-copilot-business-workflow/)

Learn how to identify and define how Microsoft 365 Copilot can best fit into and enhance your specific business workflows.

`📦 Module · ~20m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Develop finance skills with AI agents](https://learn.microsoft.com/training/modules/develop-finance-skills-ai-agents/)

Discover how AI agents in Microsoft 365 Copilot can assist finance professionals with analysis, reporting, and decision support tasks.

`📦 Module · ~30m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Develop marketing skills with AI agents](https://learn.microsoft.com/training/modules/develop-marketing-skills-ai-agents/)

Discover how AI agents in Microsoft 365 Copilot can assist marketing professionals with campaign planning, content creation, and customer insights.

`📦 Module · ~30m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Develop sales skills with AI agents](https://learn.microsoft.com/training/modules/develop-sales-skills-ai-agents/)

Discover how AI agents in Microsoft 365 Copilot can assist sales professionals with prospecting, follow-up, and opportunity management.

`📦 Module · ~30m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Draft a campaign brief using Copilot in Word](https://learn.microsoft.com/training/modules/draft-campaign-brief-copilot-word/)

Step-by-step guidance on using Microsoft 365 Copilot in Word to draft a professional marketing campaign brief.

`📦 Module · ~20m` | **Level:** Beginner | **Tags:** Microsoft Copilot, Word

#### [Draft and refine business content using Microsoft 365 Copilot](https://learn.microsoft.com/training/modules/draft-refine-business-content-copilot/)

Learn how to use Microsoft 365 Copilot to draft, refine, and polish business documents and communications.

`📦 Module · ~25m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Draft impactful documents using AI](https://learn.microsoft.com/training/modules/draft-impactful-documents-with-ai/)

Learn how to use AI-powered tools in Microsoft 365 to create clear, compelling, and well-structured documents.

`📦 Module · ~30m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Draft, analyze, and present with Microsoft 365 Copilot](https://learn.microsoft.com/training/paths/draft-analyze-present-microsoft-365-copilot/)

A learning path covering how to use Microsoft 365 Copilot to draft content, analyze information, and create presentations for business scenarios.

`🛤️ Learning Path` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Edit and transform content with Microsoft 365 Copilot](https://learn.microsoft.com/training/modules/edit-transform-content-with-microsoft-copilot-microsoft-365/)

Learn how to use Microsoft 365 Copilot to edit, rewrite, and transform existing content to improve quality, tone, and clarity.

`📦 Module · 31m` | **Level:** Beginner | **Tags:** Microsoft Copilot, Business User

#### [Empower your workforce with Microsoft 365 Copilot Use Cases](https://learn.microsoft.com/training/paths/empower-workforce-copilot-use-cases/)

Comprehensive learning path covering Copilot use cases across departments: Executives, Sales, IT, HR, Finance, Marketing, Operations, Legal, Customer Service, and Communications.

`🛤️ Learning Path · 14h` | **Level:** Beginner | **Tags:** Microsoft 365, Administrator

#### [Empower your workforce with Microsoft 365 Copilot: Communications Use Case](https://learn.microsoft.com/training/modules/empower-workforce-copilot-communications/)

Explores how communications professionals can use Microsoft 365 Copilot to craft messages, manage stakeholder updates, and streamline outreach.

`📦 Module · ~1h 20m` | **Level:** Beginner | **Tags:** Microsoft 365

#### [Empower your workforce with Microsoft 365 Copilot: Customer Service Use Case](https://learn.microsoft.com/training/modules/empower-workforce-copilot-customer-service/)

Explores how customer service teams can use Microsoft 365 Copilot to respond faster, summarize cases, and improve customer outcomes.

`📦 Module · ~1h 20m` | **Level:** Beginner | **Tags:** Microsoft 365

#### [Empower your workforce with Microsoft 365 Copilot: Executives Use Case](https://learn.microsoft.com/training/modules/empower-workforce-copilot-executives/)

Explores how executives can use Microsoft 365 Copilot to prepare for meetings, synthesize reports, and communicate strategy more effectively.

`📦 Module · 1h 23m` | **Level:** Beginner | **Tags:** Microsoft 365

#### [Empower your workforce with Microsoft 365 Copilot: Finance Use Case](https://learn.microsoft.com/training/modules/empower-workforce-copilot-finance/)

Explores how finance teams can use Microsoft 365 Copilot to analyze data, create reports, and streamline financial workflows.

`📦 Module · 1h 18m` | **Level:** Beginner | **Tags:** Microsoft 365

#### [Empower your workforce with Microsoft 365 Copilot: HR Use Case](https://learn.microsoft.com/training/modules/empower-workforce-copilot-hr/)

Explores how HR professionals can use Microsoft 365 Copilot to improve recruiting, onboarding, and employee communications.

`📦 Module · 1h 23m` | **Level:** Beginner | **Tags:** Microsoft 365

#### [Empower your workforce with Microsoft 365 Copilot: IT Use Case](https://learn.microsoft.com/training/modules/enhance-prompting-copilot-it/)

Explores how IT professionals can use Microsoft 365 Copilot to enhance documentation, troubleshoot issues, and manage communications.

`📦 Module · 1h 7m` | **Level:** Beginner | **Tags:** Microsoft 365

#### [Empower your workforce with Microsoft 365 Copilot: Legal Use Case](https://learn.microsoft.com/training/modules/empower-workforce-copilot-legal/)

Explores how legal teams can use Microsoft 365 Copilot to review contracts, research precedents, and draft correspondence faster.

`📦 Module · ~1h 20m` | **Level:** Beginner | **Tags:** Microsoft 365

#### [Empower your workforce with Microsoft 365 Copilot: Marketing Use Case](https://learn.microsoft.com/training/modules/empower-workforce-copilot-marketing/)

Explores how marketing teams can use Microsoft 365 Copilot to create campaigns, analyze performance, and collaborate on content.

`📦 Module · 1h 17m` | **Level:** Beginner | **Tags:** Microsoft 365

#### [Empower your workforce with Microsoft 365 Copilot: Operations Use Case](https://learn.microsoft.com/training/modules/empower-workforce-copilot-operations/)

Explores how operations teams can use Microsoft 365 Copilot to streamline workflows, track projects, and optimize processes.

`📦 Module · 1h 38m` | **Level:** Beginner | **Tags:** Microsoft 365

#### [Empower your workforce with Microsoft 365 Copilot: Sales Use Case](https://learn.microsoft.com/training/modules/empower-workforce-copilot-sales/)

Explores how sales professionals can use Microsoft 365 Copilot to research prospects, craft pitches, and manage follow-ups.

`📦 Module · 1h 25m` | **Level:** Beginner | **Tags:** Microsoft 365

#### [Employ Copilot Chat as your AI assistant](https://learn.microsoft.com/training/modules/employ-copilot-chat-ai-assistant/)

Learn how to use Microsoft Copilot Chat as your AI assistant for everyday work tasks, from research and drafting to summarizing and organizing.

`📦 Module · ~20m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Enhance meeting productivity with Copilot in Microsoft Teams](https://learn.microsoft.com/training/modules/enhance-meeting-productivity-copilot-teams/)

Discover how to use Microsoft 365 Copilot in Teams to prepare for meetings, capture key points, and follow up with action items.

`📦 Module · ~30m` | **Level:** Beginner | **Tags:** Microsoft Teams, Microsoft 365 Copilot

#### [Enhance your productivity with prebuilt Microsoft 365 Copilot agents](https://learn.microsoft.com/training/modules/enhance-productivity-prebuilt-copilot-agents/)

Discover the prebuilt AI agents available in Microsoft 365 Copilot and learn how to configure and use them to automate everyday tasks.

`📦 Module · ~30m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Explore Microsoft 365 Copilot and agents](https://learn.microsoft.com/training/modules/explore-microsoft-365-copilot-agents/)

Explore what Microsoft 365 Copilot agents are, how they differ from standard Copilot, and how they can be used to automate and enhance workplace tasks.

`📦 Module · ~20m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Explore prebuilt Microsoft 365 Copilot agents](https://learn.microsoft.com/training/modules/explore-prebuilt-microsoft-365-copilot-agents/)

Discover prebuilt agents available within Microsoft 365 Copilot, understand their capabilities, and learn when and how to use them.

`📦 Module · ~20m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Explore the possibilities with Microsoft 365 Copilot](https://learn.microsoft.com/training/modules/explore-possibilities-microsoft-365-copilot/)

Explore the wide range of capabilities Microsoft 365 Copilot offers, from drafting and summarizing to data analysis and meeting support.

`📦 Module · 33m` | **Level:** Beginner | **Tags:** Microsoft 365, Administrator

#### [From inbox to impact: Improve your email workflows with AI](https://learn.microsoft.com/training/modules/improve-email-workflows-with-ai/)

Discover how to use AI-powered tools in Microsoft 365 to process email faster, draft better replies, and manage your inbox more effectively.

`📦 Module · ~30m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Get more done with Copilot Cowork](https://learn.microsoft.com/training/modules/get-more-done-copilot-cowork/)

Learn how to use Copilot Cowork features in Microsoft 365 to collaborate with AI assistance, co-author documents, and work faster with teammates.

`📦 Module · ~20m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Get ready to work with Microsoft 365 Copilot](https://learn.microsoft.com/training/modules/get-ready-work-microsoft-365-copilot/)

A practical guide to setting up and starting to work effectively with Microsoft 365 Copilot in your daily workflow.

`📦 Module · ~20m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Get started with Microsoft 365 Copilot](https://learn.microsoft.com/training/paths/get-started-with-microsoft-365-copilot/)

Comprehensive learning path covering the essentials of Microsoft 365 Copilot: what it is, how it works, and how to start using it effectively.

`🛤️ Learning Path · 1h 31m` | **Level:** Beginner | **Tags:** Microsoft 365, Administrator

#### [Get started with Microsoft 365 Copilot (1-hour)](https://learn.microsoft.com/training/courses/get-started-microsoft-365-copilot-1-hour/)

Concise 1-hour instructor-led introduction to Microsoft 365 Copilot—ideal for initial awareness and getting started quickly.

`🎓 Course · 1h` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Get started with Microsoft 365 Copilot (3-hour)](https://learn.microsoft.com/training/courses/get-started-microsoft-365-copilot-3-hour/)

Extended 3-hour instructor-led introduction to Microsoft 365 Copilot with deeper hands-on practice across M365 apps.

`🎓 Course · 3h` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Introduction to Microsoft 365 Copilot](https://learn.microsoft.com/training/modules/introduction-microsoft-365-copilot/)

An introduction to what Microsoft 365 Copilot is, how it works, where it appears, and how it can help in everyday work scenarios.

`📦 Module · 28m` | **Level:** Beginner | **Tags:** Microsoft 365, Administrator

#### [Make your meetings more productive with AI](https://learn.microsoft.com/training/modules/make-meetings-more-productive-with-ai/)

Learn how to use AI tools to prepare for, run, and follow up on meetings more effectively with Microsoft 365 Copilot in Teams.

`📦 Module · ~30m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Manage agents for Microsoft 365 Copilot](https://learn.microsoft.com/training/modules/manage-agents-microsoft-365-copilot/)

Learn how end users can manage, configure, and control the AI agents available to them in Microsoft 365 Copilot.

`📦 Module · ~20m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Manage email efficiently with Microsoft Outlook and Copilot Chat](https://learn.microsoft.com/training/modules/manage-email-outlook-copilot-chat/)

Explore how to use Microsoft 365 Copilot in Outlook to triage email, draft replies, summarize threads, and take action faster.

`📦 Module · ~25m` | **Level:** Beginner | **Tags:** Outlook, Microsoft 365 Copilot

#### [Manage meetings and collaboration using Microsoft 365 Copilot](https://learn.microsoft.com/training/modules/manage-meetings-collaboration-copilot/)

Learn how Microsoft 365 Copilot can help you organize, run, and follow up on meetings—and collaborate more effectively with your team.

`📦 Module · ~25m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Microsoft 365 Copilot and Copilot agents](https://learn.microsoft.com/training/modules/microsoft-365-copilot-agents/)

Explore how Microsoft 365 Copilot and Copilot agents work together to help users complete tasks, access information, and automate workflows.

`📦 Module · ~20m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Optimize business processes with Microsoft 365 Copilot](https://learn.microsoft.com/training/modules/optimize-business-processes-copilot/)

Learn how to identify, redesign, and optimize business processes by integrating Microsoft 365 Copilot into existing workflows.

`📦 Module · ~30m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Share and use agents](https://learn.microsoft.com/training/modules/share-use-copilot-agents/)

Learn how to share Microsoft 365 Copilot agents with colleagues and how to discover and use agents shared by others in your organization.

`📦 Module · ~15m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Summarize and simplify information with Microsoft 365 Copilot](https://learn.microsoft.com/training/modules/summarize-simplify-information-with-microsoft-copilot-microsoft-365/)

Learn how to use Microsoft 365 Copilot to summarize long documents, email threads, meetings, and complex information quickly and clearly.

`📦 Module · 34m` | **Level:** Beginner | **Tags:** Microsoft Copilot, Business User

#### [Transform ideas into action with Copilot Chat (Basic)](https://learn.microsoft.com/training/paths/explore-microsoft-365-copilot-business-chat/)

Learn how to use Copilot Chat to turn ideas into action—drafting content, getting answers, and working across your M365 data.

`🛤️ Learning Path · 1h 23m` | **Level:** Beginner | **Tags:** Microsoft 365, Business User

#### [Turn information into decisions with AI agents](https://learn.microsoft.com/training/modules/turn-information-decisions-ai-agents/)

Learn how AI agents can help you process large volumes of information, surface key insights, and support better decision-making.

`📦 Module · ~30m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Uncover new data insights with AI](https://learn.microsoft.com/training/modules/uncover-new-data-insights-with-ai/)

Explore how to use AI-powered tools in Microsoft 365 Copilot to uncover patterns, trends, and insights from your business data.

`📦 Module · ~30m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Unlock productivity and unleash creativity with AI powered chat](https://learn.microsoft.com/training/modules/unlock-productivity-creativity-ai-chat/)

Discover how Microsoft 365 Copilot Chat can unlock productivity and creative potential by acting as an intelligent AI assistant throughout your workday.

`📦 Module · ~25m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Unlock productivity with generative AI](https://learn.microsoft.com/training/modules/unlock-productivity-generative-ai/)

Learn the fundamentals of generative AI and how Microsoft 365 Copilot applies it to help you get more done in less time.

`📦 Module · ~20m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Work smarter in Excel with Copilot Chat](https://learn.microsoft.com/training/modules/work-smarter-excel-copilot-chat/)

Discover how to use Microsoft 365 Copilot in Excel to analyze data, generate formulas, create charts, and surface insights with simple prompts.

`📦 Module · ~25m` | **Level:** Beginner | **Tags:** Excel, Microsoft 365 Copilot

#### [Work smarter with AI](https://learn.microsoft.com/training/modules/work-smarter-with-ai/)

A broad introduction to working smarter using AI tools available in Microsoft 365, including Copilot Chat and app-specific features.

`📦 Module · ~25m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Work smarter with Copilot across your Microsoft 365 apps](https://learn.microsoft.com/training/modules/work-smarter-copilot-microsoft-365-apps/)

Learn how Microsoft 365 Copilot works consistently across Word, Excel, PowerPoint, Outlook, and Teams to help you work more efficiently.

`📦 Module · ~30m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Work smarter with Copilot prompts for IT professionals](https://learn.microsoft.com/training/modules/work-smarter-copilot-prompts-it/)

Explore scenario-specific Copilot prompts tailored for IT professionals to improve documentation, analysis, and communication tasks.

`📦 Module · ~30m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Work smarter with Copilot prompts for marketing professionals](https://learn.microsoft.com/training/modules/work-smarter-copilot-prompts-marketing/)

Explore scenario-specific Copilot prompts tailored for marketing professionals to boost content creation, campaign planning, and audience insights.

`📦 Module · ~30m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Work smarter with Copilot prompts for Operations professionals](https://learn.microsoft.com/training/modules/work-smarter-copilot-prompts-operations/)

Explore scenario-specific Copilot prompts tailored for operations professionals to streamline project tracking, reporting, and process management.

`📦 Module · ~30m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Craft a compelling product pitch using AI](https://learn.microsoft.com/training/modules/craft-compelling-product-pitch-using-ai/)

Learn how to leverage Microsoft 365 Copilot to research, draft, and refine a persuasive product pitch from initial idea to final presentation.

`📦 Module · ~30m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Streamline training plans with AI tools](https://learn.microsoft.com/training/modules/streamline-training-plans-ai-tools/)

Discover how to use Microsoft 365 Copilot to design, draft, and organize employee training plans and learning materials.

`📦 Module · ~25m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

### 🔹 Intermediate

#### [Empower your workforce with Microsoft 365 Copilot Use Cases](https://learn.microsoft.com/training/courses/ms-4004/)

Instructor-led course on deploying M365 Copilot use cases across the organization—Sales, HR, Finance, Marketing, Operations, and more. Builds on self-paced use case modules.

`🎓 Course · 1 Day` | **Level:** Intermediate | **Tags:** Microsoft 365, Business User

---

## 🛡️ Admin & IT Track

> For IT admins, security pros, and change managers: deploy Copilot, manage governance, configure Purview compliance, and drive adoption across your organization.

### 🔹 Beginner

#### [Envision a successful adoption of Microsoft 365 Copilot](https://learn.microsoft.com/training/modules/envision-successful-adoption-microsoft-365-copilot/)

Learn how to build a vision and business case for adopting Microsoft 365 Copilot, including identifying value scenarios and engaging stakeholders.

`📦 Module · ~25m` | **Level:** Beginner | **Tags:** Microsoft Copilot

#### [Explore user enablement strategies for adopting Microsoft 365 Copilot](https://learn.microsoft.com/training/modules/explore-user-enablement-strategies-microsoft-365-copilot/)

Explore strategies and frameworks for enabling users to adopt Microsoft 365 Copilot effectively across your organization.

`📦 Module · ~20m` | **Level:** Beginner | **Tags:** Microsoft Copilot

#### [MS-4007: Discover how to drive enablement of Microsoft 365 Copilot in your organization](https://learn.microsoft.com/training/courses/ms-4007/)

Instructor-led course on planning and executing a Microsoft 365 Copilot enablement program, including readiness, training, and change management.

`🎓 Course` | **Level:** Beginner | **Tags:** Microsoft 365

#### [Onboard and empower your employees to use Microsoft 365 Copilot efficiently](https://learn.microsoft.com/training/modules/onboard-empower-employees-microsoft-365-copilot/)

Learn how to onboard employees to Microsoft 365 Copilot with effective training plans, resources, and support structures.

`📦 Module · ~20m` | **Level:** Beginner | **Tags:** Microsoft Copilot

#### [Plan your organization's AI skilling journey with Microsoft 365 Copilot](https://learn.microsoft.com/training/modules/plan-ai-skilling-journey-microsoft-365-copilot/)

Learn how to build a structured AI skilling plan for your organization, aligned to roles and business objectives.

`📦 Module · ~20m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Prepare your organization for Microsoft 365 Copilot](https://learn.microsoft.com/training/modules/prepare-organization-microsoft-365-copilot/)

Understand the technical, licensing, and governance prerequisites for deploying Microsoft 365 Copilot in your organization.

`📦 Module · ~25m` | **Level:** Beginner | **Tags:** Microsoft Copilot

#### [Perform basic administrative tasks for Microsoft 365 Copilot](https://learn.microsoft.com/training/modules/perform-basic-administrative-tasks-microsoft-365-copilot/)

Learn the foundational admin tasks for managing Microsoft 365 Copilot: licensing, settings, user management, and monitoring usage.

`📦 Module · ~25m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Perform basic administrative tasks for Microsoft 365 Copilot agents](https://learn.microsoft.com/training/modules/perform-basic-administrative-tasks-microsoft-365-copilot-agents/)

Learn how administrators can manage, approve, and control agents available to users in the Microsoft 365 Copilot environment.

`📦 Module · ~25m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Explore Microsoft 365 Copilot and agent administration](https://learn.microsoft.com/training/modules/explore-microsoft-365-copilot-agent-administration/)

Explore the administrative controls, dashboards, and policies available for managing Microsoft 365 Copilot and Copilot agents.

`📦 Module · ~20m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

#### [Drive value and maximize the impact of Microsoft 365 Copilot within your organization](https://learn.microsoft.com/training/modules/drive-value-maximize-impact-microsoft-365-copilot/)

Learn how to measure ROI, track adoption, and maximize the business impact of Microsoft 365 Copilot across your organization.

`📦 Module · ~20m` | **Level:** Beginner | **Tags:** Microsoft Copilot

#### [Introduction to Microsoft 365 and AI administration](https://learn.microsoft.com/training/modules/introduction-microsoft-365-ai-administration/)

Introduces the Microsoft 365 admin center controls for AI features, including Copilot settings, data governance, and usage monitoring.

`📦 Module · ~25m` | **Level:** Beginner | **Tags:** Microsoft 365 Copilot

### 🔹 Intermediate

#### [Apply principles of Zero Trust to Microsoft Copilots](https://learn.microsoft.com/training/modules/zero-trust-microsoft-copilots/)

Learn how to apply Zero Trust security principles to Microsoft 365 Copilot deployments to ensure data protection and least-privilege access.

`📦 Module · ~30m` | **Level:** Intermediate | **Tags:** Microsoft 365, Microsoft Copilot

#### [Enhance endpoint security with Microsoft Intune and Microsoft Security Copilot](https://learn.microsoft.com/training/paths/enhance-endpoint-security-microsoft-intune-copilot/)

Learn how to use Microsoft Security Copilot and Intune together to detect threats, remediate vulnerabilities, and manage endpoints more securely.

`🛤️ Learning Path · 4h 30m` | **Level:** Intermediate | **Tags:** Microsoft Intune, Microsoft Security Copilot

#### [Examine data security and compliance in Microsoft 365 Copilot](https://learn.microsoft.com/training/modules/examine-data-security-compliance-microsoft-365-copilot/)

Examine the data security and compliance controls in Microsoft 365 Copilot, including data processing, privacy boundaries, and audit logging.

`📦 Module · ~30m` | **Level:** Intermediate | **Tags:** Microsoft 365, Administrator

#### [Investigate data security risks with Microsoft Purview Data Security Posture Management](https://learn.microsoft.com/training/modules/investigate-data-security-risks-purview-dspm/)

Learn how to use Microsoft Purview Data Security Posture Management to identify, investigate, and remediate data security risks in your environment.

`📦 Module · ~35m` | **Level:** Intermediate | **Tags:** Microsoft Purview

#### [Manage compliance with Microsoft Purview for Microsoft 365 Copilot](https://learn.microsoft.com/training/modules/purview-ai-data-compliance/)

Learn how to configure and manage Microsoft Purview compliance controls to govern AI interactions in Microsoft 365 Copilot, including audit and communication compliance.

`📦 Module · 37m` | **Level:** Intermediate | **Tags:** Microsoft 365, Microsoft Purview

#### [Manage Microsoft 365 Copilot](https://learn.microsoft.com/training/modules/manage-microsoft-365-copilot/)

Covers the key management tasks for Microsoft 365 Copilot administrators: policy management, feature configuration, and usage reporting.

`📦 Module · ~30m` | **Level:** Intermediate | **Tags:** Microsoft 365 Copilot

#### [Manage Microsoft 365 Copilot administration](https://learn.microsoft.com/training/modules/manage-microsoft-365-copilot-administration/)

Deep-dive into Microsoft 365 Copilot admin capabilities: managing licenses, agent permissions, data settings, and org-wide Copilot policies.

`📦 Module · ~35m` | **Level:** Intermediate | **Tags:** Microsoft 365 Copilot

#### [Manage Microsoft 365 Copilot extensibility](https://learn.microsoft.com/training/modules/manage-microsoft-365-copilot-extensibility/)

Learn how administrators control which agents and extensions are available in Microsoft 365 Copilot, including approval workflows and governance.

`📦 Module · 33m` | **Level:** Intermediate | **Tags:** Microsoft 365, Administrator

#### [Orchestrate configuration of prebuilt agents and apps](https://learn.microsoft.com/training/modules/orchestrate-configuration-prebuilt-agents-apps/)

Learn how to configure and orchestrate the prebuilt Microsoft 365 Copilot agents and apps for deployment across your organization.

`📦 Module · ~25m` | **Level:** Intermediate | **Tags:** Microsoft 365 Copilot

#### [Prepare for Microsoft 365 Copilot extensibility](https://learn.microsoft.com/training/paths/prepare-microsoft-365-copilot-extensibility/)

Learn the prerequisites, architecture, and governance considerations for extending Microsoft 365 Copilot in your organization.

`🛤️ Learning Path · 1h 2m` | **Level:** Intermediate | **Tags:** Microsoft 365, Administrator

#### [Prepare security and compliance to support Microsoft 365 Copilot](https://learn.microsoft.com/training/modules/prepare-security-compliance-microsoft-365-copilot/)

Learn how to configure security and compliance controls in Microsoft 365 to safely deploy Copilot, including information barriers, sensitivity labels, and retention policies.

`📦 Module · ~30m` | **Level:** Intermediate | **Tags:** Microsoft 365, Administrator

#### [Protect information in a Microsoft 365 Copilot environment using Microsoft Purview](https://learn.microsoft.com/training/modules/protect-information-copilot-purview/)

Learn how to use Microsoft Purview Information Protection to classify, label, and protect data in Microsoft 365 Copilot environments.

`📦 Module · ~35m` | **Level:** Intermediate | **Tags:** Microsoft Purview, Microsoft 365 Copilot

#### [Secure AI interactions and environments with Microsoft Purview](https://learn.microsoft.com/training/modules/secure-ai-interactions-purview/)

Learn how Microsoft Purview can secure AI interactions, govern AI-generated data, and apply compliance controls in Copilot environments.

`📦 Module · ~30m` | **Level:** Intermediate | **Tags:** Microsoft Purview

#### [Secure and govern Microsoft 365 Copilot interactions with Microsoft Purview](https://learn.microsoft.com/training/modules/secure-govern-copilot-purview/)

Explore how to use Microsoft Purview to audit, govern, and secure interactions within Microsoft 365 Copilot across your organization.

`📦 Module · ~30m` | **Level:** Intermediate | **Tags:** Microsoft Purview, Microsoft 365 Copilot

#### [Secure Microsoft 365 Copilot interactions with Microsoft Purview](https://learn.microsoft.com/training/modules/secure-copilot-interactions-purview/)

Learn targeted controls for securing Microsoft 365 Copilot interactions using Microsoft Purview communication compliance and audit capabilities.

`📦 Module · ~30m` | **Level:** Intermediate | **Tags:** Microsoft Purview, Microsoft 365 Copilot

#### [Secure sensitive data with Microsoft Purview Ninja training scenarios](https://learn.microsoft.com/training/modules/purview-ninja-secure-sensitive-data/)

Advanced Purview Ninja scenario training covering data classification, sensitivity labels, DLP, and insider risk in Copilot environments.

`📦 Module · ~45m` | **Level:** Intermediate | **Tags:** Microsoft Purview

---

*Auto-generated from Microsoft Learn API – July 2026. Sources: M365 + Copilot · Copilot Agents · Copilot Studio searches.*

---

### 📋 Summary

| Track | Beginner | Intermediate | Advanced | Total |
|-------|----------|--------------|----------|-------|
| ⚙️ Tech Track | 27 | 15 | 3 | **45** |
| 👤 User Track | 64 | 1 | — | **65** |
| 🛡️ Admin & IT Track | 11 | 15 | — | **26** |
| **Total** | **102** | **31** | **3** | **136** |

**Key notes for SharePoint use:**
- **Quick Links web part** → Use the URL + title only (strip descriptions)
- **Text/Rich Text web part** → Paste the markdown as-is; SharePoint will render headers and links
- **Highlighted Content / People web part** → Deep link directly to `https://learn.microsoft.com/training/...` URLs
- The file is saved to your OneDrive folder so you can open it directly in a text editor or VS Code to copy sections
