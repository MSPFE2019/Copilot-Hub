# Copilot Hub — Localization packs

This folder contains **optional, maintainable localization content packs** for the Copilot Hub
site. The default deployment (`Deploy-CopilotHub.ps1` + `template.pnp`) is always English
(`en-US`) — localization is an explicit, opt-in second step that never changes the base template.

## Why an overlay instead of per-language `.pnp` files

`template.pnp` is a binary provisioning package (36 pages, 27 embedded image files, full navigation).
Forking it once per language would mean four archives to keep in sync by hand, with no diff-able
history and a high risk of drift. Instead, each locale is a small, reviewable JSON content pack
that maps a stable **key** to translated text. A single script, `Apply-Localization.ps1`,
re-applies a pack to an already-deployed site using the same idempotent PnP cmdlets the rest of
the toolkit uses. The English base experience is untouched unless you explicitly run the script.

## Supported locales

| Locale | Language | File |
| --- | --- | --- |
| `es-ES` | Spanish (Spain) | `localization/es-ES/content.json` |
| `fr-FR` | French (France) | `localization/fr-FR/content.json` |
| `de-DE` | German (Germany) | `localization/de-DE/content.json` |

All strings in these packs are original, plain-language translations of this project's own
authored copy (navigation labels, page titles, site-column display names, list titles, and the
Home / Getting Started / GitHub Copilot page introductions). No text is copied from Microsoft or
GitHub marketing pages — see `ReadMe.md` for that policy.

## Content pack structure

Each `content.json` has four sections:

```jsonc
{
  "locale": "es-ES",
  "navigation": { "Home": "Inicio", "Products": "Productos", "...": "..." },
  "pages": {
    "Home.aspx":            { "title": "Inicio" },
    "GitHub-Copilot.aspx":  { "title": "GitHub Copilot", "introText": "<p>...</p>" }
  },
  "siteColumns": { "CopilotProduct": "Producto", "...": "..." },
  "lists": { "Learning Paths": "Rutas de aprendizaje", "...": "..." }
}
```

- `navigation` — maps the **English navigation node title** (as provisioned by `template.pnp`) to
  its localized label. Keys must match the `template.pnp` navigation titles exactly;
  `Test-CopilotHubPackage.ps1` fails the release if a key has no matching node or a node has no key.
- `pages` — keyed by page filename (`PageName` in the template). `title` renames the page in the
  Site Pages library; `introText` (where present) replaces the first "Text" web part on that page
  with localized HTML. Only `Home.aspx`, `Getting-Started.aspx`, and `GitHub-Copilot.aspx` carry
  `introText` (see "Known limitations" below).
- `siteColumns` — maps the internal field name to a localized `DisplayName`.
- `lists` — maps the English list title to a localized title.

Keys and values may contain the template tokens `{parameter:CompanyName}` and `{site}`.
`Apply-Localization.ps1` resolves them from `Config.psd1` before matching or writing, so
"Copilot at {parameter:CompanyName}" matches the live node "Copilot at Contoso", and localized
links point at the real site URL.

## Applying a localization pack

Run this **after** `Deploy-CopilotHub.ps1` has successfully provisioned the site:

```powershell
.\Apply-Localization.ps1 -ConfigPath .\Config.psd1 -Locale es-ES
```

`-Locale` accepts `es-ES`, `fr-FR`, or `de-DE`. The script:

1. Loads `Config.psd1` for `SiteUrl` / `Tenant` / `ClientId` (same file `Deploy-CopilotHub.ps1`
   uses — no separate configuration).
2. Connects interactively, reusing the same delegated-permission Entra app.
3. Renames matching navigation nodes (in both the site menu and the hub menu collections), page
   titles, site-column display names, and list titles to the localized strings in the pack, and
   republishes any page it changes.
4. Reports each change made and each key from the pack that had no matching site object (so a
   typo or a renamed node in the base template is caught immediately instead of failing silently).

The script is idempotent — safe to re-run, and safe to run against an English site more than once.
It only **renames** existing objects; it never deletes or recreates content, and running it does
not affect `Deploy-CopilotHub.ps1` re-runs (which still provision the English base labels — see
"Reverting to English" below).

## Reverting to English

Re-run `Deploy-CopilotHub.ps1`. Phase 4 (`Invoke-PnPSiteTemplate`) re-applies `template.pnp`,
which restores the English navigation and page titles from the base template. Site columns and
list titles created in earlier phases are matched by internal name / URL and are **not**
recreated on re-run, so also re-run `Apply-Localization.ps1` is not needed for those to reset —
if you need those specific labels back in English, edit them directly with `Set-PnPField` /
`Set-PnPList`, or reapply the pack values from `template.pnp`'s original English text captured in
this README's table above.

## Known limitations

- The navigation, all 29 page titles, the 14 site-column names, the five list titles, and the
  introductory text on Home, Get started, and GitHub Copilot are localized. The remaining page
  bodies (product, comparison, governance, and community pages), the launch news posts, and the
  page templates stay in English.
- Product names (Copilot Chat, Microsoft Copilot, Copilot Cowork, Researcher, Analyst, SharePoint
  agents, Copilot Studio, Microsoft Foundry, GitHub Copilot) are left untranslated on purpose.
- List item data (sample Events, seeded Learning Paths and Prompt Library rows) is not localized.
- Localizing the site logo or images is not part of this pack — swap files in `assets/` and
  re-run `Deploy-CopilotHub.ps1` if you need language-specific imagery.
- Earlier packs (v5.0.0 and before) could not rename navigation: the script called a cmdlet that
  PnP.PowerShell 1.12 does not have, searched only the hub menu, and did not resolve
  `{parameter:CompanyName}`. v5.1.0 fixes all three. v5.2.0 adds labels for Copilot Cowork and
  SharePoint agents.
