# Copilot Hub v5.2.6

This release aligns the SharePoint communication-site template with the updated Copilot Hub mockup while preserving the existing site design and v5.2.5 deployment safeguards.

## Changes

- Added native Home learning entry points and a curated proposed-prompt section ahead of the existing tool catalog.
- Added five learning pages for prompting, practical tips, current Copilot access, external knowledge connectors, and connector assessment requests.
- Added navigation, library links, responsible-use cross-links, consultation/support routing, and localized navigation labels and page titles.
- Expanded offline package checks for the new pages, web parts, links, prompts, and localization.

## Compatibility notes

- New learning content uses ordinary SharePoint pages and native PnP text/QuickLinks controls; existing catalogs and approval state are unchanged.
- SharePoint controls determine final visual layout. Preview-only JavaScript, copy buttons and expanders are not part of the provisioning template.
- Connector requests point to existing configured support and consultation routes; no new intake workflow is created.
- The v5.2.5 deleted-site lookup fix and explicit purge approval guard are preserved.
- Reapplying the template retains existing overwrite and page-publishing behavior. Back up customizations and test in a non-production site before deployment.
