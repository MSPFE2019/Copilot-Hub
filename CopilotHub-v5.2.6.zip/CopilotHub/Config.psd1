# =============================================================================
# Copilot Hub - deployment configuration
#
# Edit this file ONCE per tenant. Both Deploy-CopilotHub.ps1 and
# Seed-LearningPaths.ps1 read from it. Nothing here is sensitive
# (no passwords, no client secrets).
#
# How auth works:
#   The scripts sign you in interactively using an Entra app registered
#   in YOUR tenant (one-time setup via Register-PnPApp.ps1). The app uses
#   DELEGATED permissions, so it can only do what the signed-in user can
#   do. Sign in as a SharePoint Administrator to authorize the deploy.
# =============================================================================
@{


    # ---- Tenant + site identity --------------------------------------------

    # Root SharePoint Online URL (no trailing slash)
    TenantUrl     = "https://contoso.sharepoint.com"

    # Target site URL - created if it doesn't exist
    SiteUrl       = "https://contoso.sharepoint.com/sites/copilothub"

    # Site display title
    SiteTitle     = "Copilot Hub"


    # ---- Branding ----------------------------------------------------------

    # Replaces every {parameter:CompanyName} token in the template
    # (page headers, navigation, page copy).
    CompanyName   = "Contoso"


    # ---- Ownership ---------------------------------------------------------

    # UPN of the site's primary admin. Receives owner email on creation.
    Owner         = "admin@contoso.onmicrosoft.com"


    # ---- Auth --------------------------------------------------------------

    # Entra tenant for sign-in (e.g. contoso.onmicrosoft.com).
    Tenant        = "contoso.onmicrosoft.com"

    # ClientId of the Entra app registered for PnP PowerShell.
    # Get this once by running: .\Register-PnPApp.ps1 -Tenant contoso.onmicrosoft.com
    # The app uses delegated permissions only - no tenant-wide grants.
    ClientId      = ""


    # ---- Hub registration --------------------------------------------------

    # If $true, registers the site as a SharePoint hub after provisioning
    # so other sites can join it. Requires SharePoint Admin.
    RegisterAsHub = $true


    # ---- Organization links (optional, recommended) --------------------------

    # Pages link to these. Use https:// or mailto: values. Anything left blank
    # falls back to SupportUrl, and a blank SupportUrl falls back to an email
    # to Owner — so no page ships with an empty link. Re-run the deploy after
    # filling these in.

    # Where people get help with Copilot (service desk form, Teams channel, or mailto:)
    SupportUrl        = ""

    # How employees request a Microsoft 365 Copilot or other Copilot license
    LicenseRequestUrl = ""

    # Your Copilot community (for example a Viva Engage community or Teams team)
    CommunityUrl      = ""

    # Office hours registration or recordings (for example a Teams meeting or Stream page)
    OfficeHoursUrl    = ""

    # Your organization's AI / acceptable-use policy document
    AIPolicyUrl       = ""
}
