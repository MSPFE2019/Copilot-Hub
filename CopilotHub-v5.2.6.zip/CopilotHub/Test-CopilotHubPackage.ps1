<#
.SYNOPSIS
  Release check for the Copilot Hub package. Exits with code 1 if any check fails.

.DESCRIPTION
  Run before publishing a release, and in CI. Inspects the package folder (or a
  release .zip) offline; it never connects to SharePoint.

    Package        required files, VERSION.txt, PowerShell syntax
    Security       sharing/Designer/workflow flags are off in the template AND
                   enforced by Deploy-CopilotHub.ps1 (the deploy excludes the
                   template's WebSettings/SiteSettings handlers); no list webhooks
    Content        no double-encoded HTML, unfilled placeholders, or text carried
                   over from the Power Platform template
    Links          every internal navigation and page link resolves to a page in
                   the template; no unreachable pages
    Feeds          page templates are not tagged with a Page Type that a news or
                   highlighted-content feed displays
    Accessibility  every page banner image has alternative text
    Parameters     every {parameter:X} token is supplied by the deploy script
    Localization   every pack parses and its keys match navigation, pages, lists,
                   and columns; every navigation label is covered
    Events         Events web parts that filter by category have a matching event

.PARAMETER Path
  Package folder that contains template.pnp, or a CopilotHub-v*.zip archive.
  Defaults to the folder this script is in.

.EXAMPLE
  .\Test-CopilotHubPackage.ps1

.EXAMPLE
  .\Test-CopilotHubPackage.ps1 -Path ..\CopilotHub-v5.2.6.zip
#>
[CmdletBinding()]
param(
    [string] $Path = $PSScriptRoot
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem

$script:results = New-Object System.Collections.Generic.List[object]

function Add-Result([string] $Area, [string] $Check, [bool] $Passed, [object[]] $Details = @()) {
    $script:results.Add([pscustomobject]@{
        Area    = $Area
        Check   = $Check
        Passed  = $Passed
        Details = @($Details | Where-Object { $_ })
    })
}

function Get-Decoded([string] $Text) {
    return [System.Net.WebUtility]::HtmlDecode($Text)
}

# ---------------------------------------------------------------------------
# Resolve the package folder (extract a release zip to a temp folder)
# ---------------------------------------------------------------------------
$tempRoot = $null
if ((Test-Path -LiteralPath $Path -PathType Leaf) -and $Path -like '*.zip') {
    $tempRoot = Join-Path (Get-Location).Path ("CopilotHubCheck-" + [guid]::NewGuid().ToString('N'))
    [IO.Compression.ZipFile]::ExtractToDirectory((Resolve-Path -LiteralPath $Path).Path, $tempRoot)
    $found = Get-ChildItem -LiteralPath $tempRoot -Recurse -Filter 'template.pnp' | Select-Object -First 1
    if (-not $found) { throw "No template.pnp found inside $Path" }
    $pkg = $found.DirectoryName
} else {
    $pkg = (Resolve-Path -LiteralPath $Path).Path
}

try {
    Write-Host "Checking package: $pkg" -ForegroundColor Cyan

    # -----------------------------------------------------------------------
    # Package
    # -----------------------------------------------------------------------
    $required = 'Config.psd1', 'Register-PnPApp.ps1', 'Deploy-CopilotHub.ps1', 'Seed-LearningPaths.ps1',
                'Seed-PromptLibrary.ps1', 'Apply-Localization.ps1', 'Test-CopilotHubPackage.ps1',
                'template.pnp', 'VERSION.txt', 'LICENSE', 'ReadMe.md', 'RELEASE-PROVENANCE.json'
    $missingFiles = $required | Where-Object { -not (Test-Path -LiteralPath (Join-Path $pkg $_)) }
    Add-Result 'Package' 'Required files are present' (@($missingFiles).Count -eq 0) $missingFiles

    $versionFile = Join-Path $pkg 'VERSION.txt'
    $version = if (Test-Path -LiteralPath $versionFile) { (Get-Content -LiteralPath $versionFile -Raw).Trim() } else { '' }
    Add-Result 'Package' "VERSION.txt holds a semantic version ($version)" ($version -match '^\d+\.\d+\.\d+$')

    $parseErrors = foreach ($ps1 in Get-ChildItem -LiteralPath $pkg -Filter '*.ps1') {
        $tokens = $null; $errors = $null
        [void][System.Management.Automation.Language.Parser]::ParseFile($ps1.FullName, [ref]$tokens, [ref]$errors)
        foreach ($e in $errors) { "$($ps1.Name):$($e.Extent.StartLineNumber) $($e.Message)" }
    }
    Add-Result 'Package' 'PowerShell scripts parse without errors' (@($parseErrors).Count -eq 0) $parseErrors

    # -----------------------------------------------------------------------
    # Load the provisioning template XML from template.pnp
    # -----------------------------------------------------------------------
    $zip = [IO.Compression.ZipFile]::OpenRead((Join-Path $pkg 'template.pnp'))
    try {
        $mapReader = New-Object IO.StreamReader($zip.GetEntry('ProvisioningTemplate/files-map.xml').Open())
        $filesMap = $mapReader.ReadToEnd(); $mapReader.Close()
        $key = [regex]::Match($filesMap, 'x:Key="([^"]+)">template\.xml<').Groups[1].Value
        if (-not $key) { throw 'files-map.xml does not map any entry to template.xml' }
        $xmlReader = New-Object IO.StreamReader($zip.GetEntry("Files/$key").Open())
        $templateText = $xmlReader.ReadToEnd(); $xmlReader.Close()
    } finally {
        $zip.Dispose()
    }
    [xml] $tx = $templateText
    $ns = New-Object Xml.XmlNamespaceManager($tx.NameTable)
    $ns.AddNamespace('pnp', $tx.DocumentElement.NamespaceURI)

    $deploy = Get-Content -LiteralPath (Join-Path $pkg 'Deploy-CopilotHub.ps1') -Raw
    $pages = @($tx.SelectNodes('//pnp:ClientSidePage', $ns))
    $pageNames = @($pages | ForEach-Object { $_.GetAttribute('PageName') })
    $navNodes = @($tx.SelectNodes('//pnp:NavigationNode', $ns))

    # -----------------------------------------------------------------------
    # Security
    # -----------------------------------------------------------------------
    $flags = @()
    $webSettings = $tx.SelectSingleNode('//pnp:WebSettings', $ns)
    if ($webSettings -and $webSettings.GetAttribute('MembersCanShare') -ne 'false') {
        $flags += "WebSettings MembersCanShare=$($webSettings.GetAttribute('MembersCanShare'))"
    }
    $siteSettings = $tx.SelectSingleNode('//pnp:SiteSettings', $ns)
    foreach ($attr in 'AllowDesigner', 'AllowCreateDeclarativeWorkflow', 'AllowSaveDeclarativeWorkflowAsTemplate', 'AllowSavePublishDeclarativeWorkflow') {
        if ($siteSettings -and $siteSettings.GetAttribute($attr) -ne 'false') {
            $flags += "SiteSettings $attr=$($siteSettings.GetAttribute($attr))"
        }
    }
    Add-Result 'Security' 'Template sharing, Designer, and workflow flags are off' ($flags.Count -eq 0) $flags

    $enforcement = @()
    if ($deploy -notmatch 'Set-PnPWeb[^\r\n]*-MembersCanShare:\$false') { $enforcement += 'Deploy-CopilotHub.ps1 never runs Set-PnPWeb -MembersCanShare:$false' }
    if ($deploy -notmatch 'AllowDesigner\s*=\s*\$false') { $enforcement += 'Deploy-CopilotHub.ps1 never sets AllowDesigner = $false' }
    if ($deploy -notmatch 'AllowCreateDeclarativeWorkflow\s*=\s*\$false') { $enforcement += 'Deploy-CopilotHub.ps1 never sets AllowCreateDeclarativeWorkflow = $false' }
    Add-Result 'Security' 'Deploy script enforces the hardening itself' ($enforcement.Count -eq 0) $enforcement

    $hooks = @($tx.SelectNodes('//pnp:Webhook', $ns))
    Add-Result 'Security' 'Template contains no list webhooks' ($hooks.Count -eq 0) @($hooks | ForEach-Object { $_.GetAttribute('ServerNotificationUrl') })

    # -----------------------------------------------------------------------
    # Content
    # -----------------------------------------------------------------------
    $residuePatterns = [ordered]@{
        'Lorem ipsum filler'                              = 'lorem ipsum'
        'Unfilled <COMPANY ...> placeholder'              = '(&lt;|<)\s*COMPANY'
        'Unfilled <LINK> placeholder'                     = '(&lt;|<)\s*LINK\s*(&gt;|>)'
        'Unfilled [Replace ...] placeholder'              = '\[\s*replace'
        'Tenant graphic placeholder'                      = 'tenant graphic'
        '"Power Makers" (Power Platform text)'            = 'Power Makers'
        'Yammer (now Viva Engage)'                        = 'Yammer'
        '"Development Studio" (Power Platform CoE text)'  = 'Development Studio'
        'Low-code adoption text (Power Platform)'         = 'adopting low-code'
        '"Power App" hackathon text'                      = 'amazing Power App'
        'Power Platform hackathon workbook link'          = 'powerplatformhackathonworkbook'
        '"Microsoft 365 Copilot flows" (Power Platform)'  = 'Microsoft 365 Copilot flows|Copilot Studio applications'
        'Retired docs.microsoft.com link'                 = 'docs\.microsoft\.com'
        'Duplicated "Microsoft Microsoft"'                = 'Microsoft\s+Microsoft'
        '"Hackthons" typo'                                = 'Hackthons'
    }
    $escapedTag = '&lt;/?(p|span|div|a|h[1-6]|strong|em|ul|ol|li|br|table|tbody|tr|td|th)(\s|&gt;|/)'
    $residue = @(); $doubleEncoded = @()
    foreach ($page in $pages) {
        $name = $page.GetAttribute('PageName')
        $texts = @($page.SelectNodes('.//pnp:CanvasControlProperty[@Key="Text"]', $ns) | ForEach-Object { $_.GetAttribute('Value') })
        foreach ($t in $texts) {
            if ($t -match $escapedTag) { $doubleEncoded += "$name contains escaped HTML tags that render as literal text" }
        }
        $blob = ($texts + @($page.SelectNodes('.//pnp:CanvasControl', $ns) | ForEach-Object { $_.GetAttribute('JsonControlData') }) +
                 @($page.GetAttribute('Title')) + @($page.SelectNodes('./pnp:Header', $ns) | ForEach-Object { $_.GetAttribute('TopicHeader') })) -join "`n"
        foreach ($label in $residuePatterns.Keys) {
            if ($blob -match $residuePatterns[$label]) { $residue += "${name}: $label" }
        }
    }
    foreach ($node in $navNodes) {
        foreach ($label in $residuePatterns.Keys) {
            if (($node.GetAttribute('Title') + ' ' + $node.GetAttribute('Url')) -match $residuePatterns[$label]) { $residue += "Navigation '$($node.GetAttribute('Title'))': $label" }
        }
    }
    Add-Result 'Content' 'Page text is not double-encoded' ($doubleEncoded.Count -eq 0) ($doubleEncoded | Sort-Object -Unique)
    Add-Result 'Content' 'No placeholders or carried-over Power Platform text' ($residue.Count -eq 0) $residue

    $requiredNewPages = 'Copilot-Cowork.aspx', 'SharePoint-Agents.aspx'
    $missingNewPages = @($requiredNewPages | Where-Object { $pageNames -notcontains $_ })
    Add-Result 'Content' 'Copilot Cowork and SharePoint agents pages are present' ($missingNewPages.Count -eq 0) $missingNewPages

    $requiredProductLinks = @(
        'https://learn.microsoft.com/en-us/microsoft-365/copilot/cowork/',
        'https://learn.microsoft.com/en-us/microsoft-365/copilot/cowork/cowork-admin-governance',
        'https://learn.microsoft.com/en-us/microsoft-365/copilot/usage-based-billing-overview-copilot-credits',
        'https://learn.microsoft.com/en-us/microsoft-copilot-studio/billing-licensing',
        'https://learn.microsoft.com/en-us/sharepoint/get-started-sharepoint-agents',
        'https://learn.microsoft.com/en-us/sharepoint/manage-access-agents-in-sharepoint',
        'https://learn.microsoft.com/en-us/microsoft-365/copilot/pay-as-you-go/overview'
    )
    $missingProductLinks = @($requiredProductLinks | Where-Object { -not $templateText.Contains($_) })
    Add-Result 'Links' 'New product pages link to current Microsoft Learn guidance' ($missingProductLinks.Count -eq 0) $missingProductLinks

    # The content release preserves the v5.2.5 deployment fix and uses native canvas controls.
    $provenance = Get-Content -LiteralPath (Join-Path $pkg 'RELEASE-PROVENANCE.json') -Raw | ConvertFrom-Json
    $deployHash = (Get-FileHash -LiteralPath (Join-Path $pkg 'Deploy-CopilotHub.ps1') -Algorithm SHA256).Hash
    Add-Result 'Release' 'v5.2.6 provenance and preserved v5.2.5 deployment script' (
        $provenance.version -eq $version -and $version -eq '5.2.6' -and
        $provenance.basePackage -eq 'CopilotHub-v5.2.5.zip' -and
        $provenance.basePackageSha256 -eq 'AF895D0B36A5E226E87FD9EA905B41FD8109DB5DEEDD7FD4D29A1E7765BB6904' -and
        $deployHash -eq $provenance.deployScriptSha256
    )
    Add-Result 'Release' 'Deleted-site lookup enumerates then filters and retains its guard' (
        $deploy -match '(?s)\$deleted\s*=\s*Get-PnPTenantDeletedSite -ErrorAction Stop\s*\|\s*Where-Object' -and
        $deploy -match 'if \(\$deleted\)' -and $deploy -notmatch 'Get-PnPTenantDeletedSite\s+-Identity'
    )
    $draftTitles = [ordered]@{
        'Prompt-Guide.aspx' = 'Prompt guide'
        'Copilot-Tips.aspx' = 'Copilot tips & tricks'
        'Copilot-Access.aspx' = 'Get more from your Copilot access'
        'Copilot-Connectors.aspx' = 'Connect Copilot to your knowledge'
        'Connector-Request.aspx' = 'Make a useful connector request to IT'
    }
    $draftIssues = @(); $draftCopy = @{}
    foreach ($name in $draftTitles.Keys) {
        $matches = @($pages | Where-Object { $_.GetAttribute('PageName') -eq $name })
        if ($matches.Count -ne 1) { $draftIssues += "$name must exist exactly once"; continue }
        $p = $matches[0]
        if ($p.GetAttribute('Title') -ne $draftTitles[$name]) { $draftIssues += "$name title differs" }
        if ($p.GetAttribute('Layout') -ne 'Article' -or $p.GetAttribute('PromoteAsNewsArticle') -ne 'false' -or
            $p.GetAttribute('PromoteAsTemplate') -ne 'false' -or
            $p.SelectSingleNode('./pnp:FieldValues/pnp:FieldValue[@Key="PageType"]', $ns)) {
            $draftIssues += "$name is not an ordinary untagged learning page"
        }
        $texts = @($p.SelectNodes('.//pnp:CanvasControlProperty[@Key="Text"]', $ns) | ForEach-Object { $_.GetAttribute('Value') })
        $draftCopy[$name] = $texts -join "`n"
        if ($draftCopy[$name] -match 'Editor note:|<script|<button|<details|<summary|class=|data-route=|href="#|Copilot-Prompt-Guide\.docx') {
            $draftIssues += "$name includes editor/preview markup or an unwired download"
        }
    }
    Add-Result 'Release' 'Five exact routes/titles are ordinary native learning pages without preview chrome' ($draftIssues.Count -eq 0) $draftIssues

    $expectedNav = @(
        @('Prompts & agents', 'Prompt guide', 'Prompt-Guide.aspx', 'Prompt library'),
        @('Learn', 'Copilot tips & tricks', 'Copilot-Tips.aspx', 'Guided learning'),
        @('Learn', 'Copilot connectors', 'Copilot-Connectors.aspx', 'Copilot tips & tricks'),
        @('Get started', 'Get more from your access', 'Copilot-Access.aspx', 'Start here')
    )
    $navIssues = @()
    foreach ($expected in $expectedNav) {
        $parent = $navNodes | Where-Object { $_.GetAttribute('Title') -eq $expected[0] } | Select-Object -First 1
        $children = @($parent.SelectNodes('./pnp:NavigationNode', $ns))
        $titles = @($children | ForEach-Object { $_.GetAttribute('Title') })
        $index = [array]::IndexOf($titles, $expected[1])
        if ($index -lt 1 -or $titles[$index - 1] -ne $expected[3] -or
            $children[$index].GetAttribute('Url') -ne "{site}/SitePages/$($expected[2])") {
            $navIssues += "$($expected[1]) has incorrect location/order/URL"
        }
    }
    Add-Result 'Release' 'Learning navigation sits beside the intended existing entries' ($navIssues.Count -eq 0) $navIssues

    $homePage = $pages | Where-Object { $_.GetAttribute('PageName') -eq 'Home.aspx' } | Select-Object -First 1
    $homeControls = @($homePage.SelectNodes('./pnp:Sections/pnp:Section[@Order="1"]/pnp:Controls/pnp:CanvasControl[@Column="1"]', $ns) |
        Sort-Object { [int]$_.GetAttribute('Order') })
    $homeLabels = @($homeControls | ForEach-Object {
        if ($_.GetAttribute('WebPartType') -eq 'Text') {
            $_.SelectSingleNode('./pnp:CanvasControlProperties/pnp:CanvasControlProperty[@Key="Text"]', $ns).GetAttribute('Value')
        } else { ($_.GetAttribute('JsonControlData') | ConvertFrom-Json).title }
    })
    Add-Result 'Release' 'Home retains news, welcome, four entry points and curated prompts before tools' (
        $homeControls.Count -eq 6 -and $homeControls[0].GetAttribute('WebPartType') -eq 'News' -and
        $homeLabels[1] -match 'Welcome to the Copilot Hub' -and $homeLabels[2] -match 'Get more from Copilot, starting today' -and
        $homeLabels[3] -eq 'Get more from Copilot' -and $homeLabels[4] -match 'Not yet reviewed or approved' -and
        $homeLabels[5] -eq 'Explore Copilot tools'
    )
    $entry = $homeControls | Where-Object {
        $_.GetAttribute('WebPartType') -eq 'QuickLinks' -and
        ($_.GetAttribute('JsonControlData') | ConvertFrom-Json).title -eq 'Get more from Copilot'
    } | Select-Object -First 1
    $entryJson = $entry.GetAttribute('JsonControlData') | ConvertFrom-Json
    $entryTargets = 'Prompt-Library.aspx', 'Prompt-Guide.aspx', 'Copilot-Tips.aspx', 'Copilot-Access.aspx'
    $entryIssues = @()
    for ($i = 0; $i -lt 4; $i++) {
        $key = "items[$i].sourceItem.url"
        if ($entryJson.serverProcessedContent.links.$key -ne "{site}/SitePages/$($entryTargets[$i])" -or
            -not $entryJson.properties.items[$i].description) { $entryIssues += "Entry $i missing URL/description" }
    }
    Add-Result 'Release' 'Four native button QuickLinks have exact targets and descriptions' (
        $entryJson.properties.items.Count -eq 4 -and $entryJson.properties.layoutId -eq 'Button' -and
        $entryJson.properties.buttonLayoutOptions.showDescription -and $entryIssues.Count -eq 0
    ) $entryIssues
    $homePrompt = $homeLabels[4]
    $curatedMarkers = 'Make a document easier to use', 'Turn notes into clear next steps', 'Make an update audience-ready',
        'Where it works / before you start', 'Review check', 'Supply a permitted document', 'Supply permitted notes',
        'Supply the original draft', 'See all prompts', 'Write your own',
        '{site}/SitePages/Prompt-Library.aspx', '{site}/SitePages/Prompt-Guide.aspx'
    $missingCurated = @($curatedMarkers | Where-Object { -not $homePrompt.Contains($_) })
    Add-Result 'Release' 'Home curated proposed examples preserve input, access, review and library wiring' ($missingCurated.Count -eq 0) $missingCurated
    $guideMarkers = 'Summarize a document', 'Rewrite for an audience', 'Compare two policies', 'Extract actions from notes',
        'Prepare for a meeting', 'Summarize a Teams meeting', 'Analyze an attached dataset',
        'Find process guidance in a connected source', 'Make a document easier to use', 'Turn notes into clear next steps',
        'Make an update audience-ready', 'Six follow-ups to copy', 'Cut this to 100 words',
        'Separate source-supported evidence', 'State the source for each factual claim', 'List unsupported assumptions',
        'Show the calculations, formulas', 'Identify conflicting or missing evidence',
        'Fix the cause, not just the wording', 'Use responsibly and practice', 'One-page quick reference',
        'proposed prompts are not approved library entries', 'A prompt cannot grant access'
    $missingGuide = @($guideMarkers | Where-Object { -not $draftCopy['Prompt-Guide.aspx'].Contains($_) })
    Add-Result 'Release' 'Guide includes eight starter prompts, three home examples, six follow-ups and practice' ($missingGuide.Count -eq 0) $missingGuide

    $wiringIssues = @()
    foreach ($name in 'Copilot-Access.aspx', 'Copilot-at-{parameter:CompanyName}.aspx', 'Consultation-and-Office-Hours.aspx') {
        $p = $pages | Where-Object { $_.GetAttribute('PageName') -eq $name } | Select-Object -First 1
        if (-not $p.OuterXml.Contains('{site}/SitePages/Copilot-Connectors.aspx')) { $wiringIssues += "$name lacks connector explainer link" }
    }
    if (-not $draftCopy['Copilot-Connectors.aspx'].Contains('Approved Connectors list supports') -or
        -not $draftCopy['Copilot-Connectors.aspx'].Contains('{site}/SitePages/Connector-Request.aspx')) { $wiringIssues += 'Connector governance distinction/request link missing' }
    foreach ($marker in '{parameter:SupportUrl}', '{site}/SitePages/Consultation-and-Office-Hours.aspx',
                        'does not create a new intake form or submit a request', 'third-party API or connector charges') {
        if (-not $draftCopy['Connector-Request.aspx'].Contains($marker)) { $wiringIssues += "Request missing $marker" }
    }
    Add-Result 'Release' 'Connector cross-links, governance distinction and existing support route are wired' ($wiringIssues.Count -eq 0) $wiringIssues
    $referenceUrls = 'https://learn.microsoft.com/en-us/training/modules/write-effective-prompts-do-more-prompting/',
        'https://learn.microsoft.com/en-us/microsoft-365/copilot/microsoft-365-copilot-licensing',
        'https://learn.microsoft.com/en-us/copilot/overview', 'https://www.microsoft.com/en-us/copilot/pricing/enterprise',
        'https://learn.microsoft.com/en-us/microsoft-365/copilot/connectors/overview',
        'https://learn.microsoft.com/en-us/microsoft-365/copilot/connectors/prerequisites',
        'https://learn.microsoft.com/en-us/microsoft-365/copilot/connectors/manage-access-permissions'
    $allDraftCopy = $draftCopy.Values -join "`n"
    $missingReferences = @($referenceUrls | Where-Object { -not $allDraftCopy.Contains($_) })
    Add-Result 'Release' 'Licensing, cloud, permissions and source references are retained' (
        $missingReferences.Count -eq 0 -and $draftCopy['Copilot-Access.aspx'].Contains('contractual entitlement') -and
        $draftCopy['Copilot-Connectors.aspx'].Contains('zero-cost integration')
    ) $missingReferences
    $jsonErrors = @()
    foreach ($control in $tx.SelectNodes('//pnp:CanvasControl[@JsonControlData]', $ns)) {
        try { $null = $control.GetAttribute('JsonControlData') | ConvertFrom-Json }
        catch { $jsonErrors += $_.Exception.Message }
    }
    Add-Result 'Release' 'Every serialized web part has valid JSON' ($jsonErrors.Count -eq 0) $jsonErrors

    # -----------------------------------------------------------------------
    # Links and reachability
    # -----------------------------------------------------------------------
    $internalLink = [regex] '\{site\}/SitePages/([^"''<>\s?#&]+?\.aspx)'
    $navTargets = @($navNodes | ForEach-Object {
        $m = $internalLink.Match($_.GetAttribute('Url')); if ($m.Success) { $m.Groups[1].Value }
    })
    $linked = @{}
    foreach ($page in $pages) {
        $source = $page.GetAttribute('PageName')
        foreach ($m in $internalLink.Matches((Get-Decoded (Get-Decoded $page.OuterXml)))) {
            $target = [uri]::UnescapeDataString($m.Groups[1].Value)
            if ($target -ne $source) {
                if (-not $linked.ContainsKey($target)) { $linked[$target] = @() }
                $linked[$target] += $source
            }
        }
    }
    $broken = @()
    foreach ($t in $navTargets) { if ($pageNames -notcontains $t) { $broken += "Navigation -> $t" } }
    foreach ($t in $linked.Keys) { if ($pageNames -notcontains $t) { $broken += "$(($linked[$t] | Sort-Object -Unique) -join ', ') -> $t" } }
    Add-Result 'Links' 'Every internal link points to a page in the template' ($broken.Count -eq 0) $broken

    $feedTypes = @()
    foreach ($ctrl in $tx.SelectNodes('//pnp:CanvasControl[@WebPartType="ContentRollup" or @WebPartType="News"]', $ns)) {
        try {
            $json = $ctrl.GetAttribute('JsonControlData') | ConvertFrom-Json
            $filters = if ($json.properties.query) { $json.properties.query.filters } else { $json.properties.filters }
            foreach ($f in @($filters)) { if ($f.fieldname -eq 'PageType') { $feedTypes += @($f.values) } }
        } catch { }
    }
    $feedTypes = @($feedTypes | Sort-Object -Unique)
    $orphans = @()
    $templatesInFeeds = @()
    foreach ($page in $pages) {
        $name = $page.GetAttribute('PageName')
        $pageType = ($page.SelectNodes('./pnp:FieldValues/pnp:FieldValue[@Key="PageType"]', $ns) | Select-Object -First 1).Value
        if ($name -like 'Templates/*') {
            if ($feedTypes -contains $pageType) { $templatesInFeeds += "$name has Page Type '$pageType', so feeds would display the template" }
            continue
        }
        $isNews = $page.GetAttribute('PromoteAsNewsArticle') -eq 'true'
        $reachable = ($name -eq 'Home.aspx') -or ($navTargets -contains $name) -or $linked.ContainsKey($name) -or
                     ($isNews -and $feedTypes -contains $pageType) -or ($feedTypes -contains $pageType -and $pageType -ne 'News')
        if (-not $reachable) { $orphans += $name }
    }
    Add-Result 'Links' 'Every page is reachable from navigation, a link, or a feed' ($orphans.Count -eq 0) $orphans
    Add-Result 'Feeds' 'Page templates are not tagged for news or highlighted-content feeds' ($templatesInFeeds.Count -eq 0) $templatesInFeeds

    # -----------------------------------------------------------------------
    # Accessibility
    # -----------------------------------------------------------------------
    $noAlt = @()
    foreach ($page in $pages) {
        $header = $page.SelectSingleNode('./pnp:Header', $ns)
        if ($header -and $header.GetAttribute('ServerRelativeImageUrl') -and -not $header.GetAttribute('AlternativeText')) {
            $noAlt += "$($page.GetAttribute('PageName')) ($(Split-Path $header.GetAttribute('ServerRelativeImageUrl') -Leaf))"
        }
    }
    Add-Result 'Accessibility' 'Every page banner image has alternative text' ($noAlt.Count -eq 0) $noAlt

    # -----------------------------------------------------------------------
    # Parameters
    # -----------------------------------------------------------------------
    $used = @([regex]::Matches($templateText, '\{parameter:([A-Za-z0-9_]+)\}') | ForEach-Object { $_.Groups[1].Value } | Sort-Object -Unique)
    $block = [regex]::Match($deploy, '\$templateParameters\s*=\s*@\{(?<body>.*?)\r?\n\}', 'Singleline').Groups['body'].Value
    $supplied = @([regex]::Matches($block, '(?m)^\s*([A-Za-z0-9_]+)\s*=') | ForEach-Object { $_.Groups[1].Value })
    $unsupplied = @($used | Where-Object { $supplied -notcontains $_ })
    Add-Result 'Parameters' 'Every template parameter is supplied by the deploy script' ($unsupplied.Count -eq 0) ($unsupplied | ForEach-Object { "{parameter:$_} is not in `$templateParameters" })

    # -----------------------------------------------------------------------
    # Localization
    # -----------------------------------------------------------------------
    $navTitles = @($navNodes | ForEach-Object { $_.GetAttribute('Title') } | Sort-Object -Unique)
    $listTitles = @($tx.SelectNodes('//pnp:ListInstance', $ns) | ForEach-Object { $_.GetAttribute('Title') }) +
                  @([regex]::Matches($deploy, 'Title="([^"]+)";\s*Template=') | ForEach-Object { $_.Groups[1].Value })
    $columnNames = @([regex]::Matches($deploy, 'Name="(Copilot\w+)"') | ForEach-Object { $_.Groups[1].Value })
    $packs = @(Get-ChildItem -LiteralPath (Join-Path $pkg 'localization') -Recurse -Filter 'content.json' -ErrorAction SilentlyContinue)
    foreach ($packFile in $packs) {
        $locale = $packFile.Directory.Name
        try {
            $pack = Get-Content -LiteralPath $packFile.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
        } catch {
            Add-Result 'Localization' "$locale pack is valid JSON" $false @($_.Exception.Message)
            continue
        }
        $unmatched = @()
        foreach ($k in $pack.navigation.PSObject.Properties.Name) { if ($navTitles -notcontains $k) { $unmatched += "navigation '$k'" } }
        foreach ($k in $pack.pages.PSObject.Properties.Name) { if ($pageNames -notcontains $k) { $unmatched += "page '$k'" } }
        foreach ($k in $pack.lists.PSObject.Properties.Name) { if ($listTitles -notcontains $k) { $unmatched += "list '$k'" } }
        foreach ($k in $pack.siteColumns.PSObject.Properties.Name) { if ($columnNames -notcontains $k) { $unmatched += "column '$k'" } }
        Add-Result 'Localization' "$locale pack keys match the template" ($unmatched.Count -eq 0) $unmatched
        $uncovered = @($navTitles | Where-Object { $pack.navigation.PSObject.Properties.Name -notcontains $_ })
        $uncovered += @($columnNames | Where-Object { $pack.siteColumns.PSObject.Properties.Name -notcontains $_ } | ForEach-Object { "column $_" })
        $uncovered += @($draftTitles.Keys | Where-Object {
            -not $pack.pages.$_ -or -not $pack.pages.$_.title
        } | ForEach-Object { "draft page $_" })
        Add-Result 'Localization' "$locale pack covers every navigation label and column" ($uncovered.Count -eq 0) $uncovered
    }

    # -----------------------------------------------------------------------
    # Events
    # -----------------------------------------------------------------------
    $categories = @($tx.SelectNodes('//pnp:ListInstance[@Title="Events"]//pnp:DataValue[@FieldName="Category"]', $ns) | ForEach-Object { $_.InnerText })
    $emptyFeeds = @()
    foreach ($page in $pages) {
        foreach ($ctrl in $page.SelectNodes('.//pnp:CanvasControl[@WebPartType="Events"]', $ns)) {
            try { $category = ($ctrl.GetAttribute('JsonControlData') | ConvertFrom-Json).properties.selectedCategory } catch { $category = '' }
            if ($category -and $categories -notcontains $category) {
                $emptyFeeds += "$($page.GetAttribute('PageName')) shows only '$category' events, and no sample event has that category"
            }
        }
    }
    Add-Result 'Events' 'Category-filtered Events web parts have a matching event' ($emptyFeeds.Count -eq 0) $emptyFeeds

    # -----------------------------------------------------------------------
    # Report
    # -----------------------------------------------------------------------
    Write-Host ""
    foreach ($r in $script:results) {
        $mark = if ($r.Passed) { 'PASS' } else { 'FAIL' }
        $color = if ($r.Passed) { 'Green' } else { 'Red' }
        Write-Host ("[{0}] {1,-13} {2}" -f $mark, $r.Area, $r.Check) -ForegroundColor $color
        if (-not $r.Passed) {
            $r.Details | Select-Object -First 25 | ForEach-Object { Write-Host "         - $_" -ForegroundColor DarkYellow }
            if ($r.Details.Count -gt 25) { Write-Host "         ... and $($r.Details.Count - 25) more" -ForegroundColor DarkYellow }
        }
    }
    $failed = @($script:results | Where-Object { -not $_.Passed }).Count
    Write-Host ""
    if ($failed) {
        Write-Host "$failed of $($script:results.Count) checks failed." -ForegroundColor Red
    } else {
        Write-Host "All $($script:results.Count) checks passed." -ForegroundColor Green
    }
} finally {
    if ($tempRoot) { Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue }
}

if ($failed) { exit 1 } else { exit 0 }
