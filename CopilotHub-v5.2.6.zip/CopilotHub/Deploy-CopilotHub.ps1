﻿<#
.SYNOPSIS
  Deploys the Copilot Hub communication site — modeled after the Power Platform
  adoption hub template.

.DESCRIPTION
  Reads all tenant-specific values from Config.psd1.

  Two-phase deployment:

    PHASE A — Invoke-PnPSiteTemplate with template.pnp
      Applies the rich modern page layouts: News carousel on the home page,
      Events web part, Quick links, Image sections, Call to action. All pages,
      the navigation, and the Events list are provisioned in this phase.

    PHASE B — Native PnP cmdlets (idempotent, per-step errors)
      Enforces the sharing and site hardening, adds the Copilot-specific site
      columns, four additional lists (Learning Paths, Agent Catalog, Approved
      Connectors, Prompt Library), list views, starter content, the embedded
      list views on the Prompt library and Agent catalog pages, and branded
      asset uploads that the template does not cover.

  Sign-in:
    The script opens a browser once. Sign in as a SharePoint Administrator
    (or Global Admin). Auth flows through an Entra app registered in YOUR
    tenant (one-time setup via Register-PnPApp.ps1) using DELEGATED
    permissions — the app can only do what you can do.

  Phases:
    0. Load Config.psd1, validate required values, and resolve the optional
       organization links (support, license request, community, office hours,
       AI policy) with safe fallbacks
    1. Verify PnP.PowerShell 1.12.x is installed for template compatibility
    2. Connect to <tenant>-admin.sharepoint.com (interactive sign-in), create
       the communication site if needed, and register it as a hub site
    3. Connect to the site and pre-create destination folders
       (SitePages/Templates, SiteAssets/Images) so the template's page saves
       and embedded-image uploads do not 404
    4. Apply template.pnp  (pages, nav, Events list, images, web parts)
    4b. Enforce sharing and site hardening (the template's WebSettings and
        SiteSettings handlers are excluded in step 4, so this step applies them)
    5. Copilot-specific site columns  (14 columns; new choices are added to
       existing columns on re-run)
    6. Copilot-specific lists  (Learning Paths, Agent Catalog, Approved
       Connectors, Prompt Library) + field refs + default view columns
    7. Custom views (Learning Paths, approved prompts, approved agents)
    8. Upload branded assets to /SiteAssets/CopilotHub/ and set the site logo
    9. Seed Learning Paths and starter prompts (reuses connection — no extra login)
    9b. Embed the approved-prompts and approved-agents views on their pages
    10. Optional: apply a localization content pack if -Locale was supplied
        (reuses connection — no extra login)

  Every phase is idempotent. Safe to re-run.

  Logging:
    The entire run is captured to two timestamped files in this script's
    folder (not %TEMP%), so any failure at any phase is diagnosable:
      CopilotHub-deploy-<timestamp>.log     — full console transcript
      CopilotHub-pnptrace-<timestamp>.log   — detailed PnP framework trace
        (this is the log that reveals the real server error behind a generic
         "SharePoint Rest service exception").

.PARAMETER ConfigPath
  Path to Config.psd1. Defaults to .\Config.psd1 next to this script.

.PARAMETER PurgeConflictingSite
  Explicitly permits permanent removal of a deleted or errored site at the
  configured URL. Without this switch, deployment stops and preserves the site.

.PARAMETER Locale
  Optional. One of: es-ES, fr-FR, de-DE. When supplied, Apply-Localization.ps1
  runs automatically after the English base site is fully provisioned and
  seeded, applying the matching localization content pack from .\localization\.
  The base template and its English labels are always deployed first; the
  localization pass only renames existing navigation, pages, site columns, and
  lists. Omit this parameter to deploy the English-only experience (default).
  See .\localization\README.md for pack contents and limitations.

.EXAMPLE
  .\Deploy-CopilotHub.ps1

.EXAMPLE
  .\Deploy-CopilotHub.ps1 -ConfigPath .\Config.Prod.psd1

.EXAMPLE
  .\Deploy-CopilotHub.ps1 -Locale fr-FR
#>
[CmdletBinding()]
param(
    [string] $ConfigPath = (Join-Path $PSScriptRoot 'Config.psd1'),
    [switch] $PurgeConflictingSite,
    [ValidateSet('es-ES', 'fr-FR', 'de-DE')]
    [string] $Locale
)

$ErrorActionPreference = 'Stop'

function Write-Step([string] $Message) {
    Write-Host ""
    Write-Host "==> $Message" -ForegroundColor Cyan
}

function Write-Item([string] $Message) {
    Write-Host "    $Message"
}

function Write-Warn([string] $Message) {
    Write-Host "    $Message" -ForegroundColor Yellow
}

# Ensure a site-relative folder path exists, creating each missing child under
# its parent. Top-level segments (e.g. SitePages, SiteAssets) are document
# libraries — see Ensure-SiteAssetsLibrary for why SiteAssets needs special
# handling. Passing "/" to Add-PnPFolder throws "Server relative urls must
# start with SPWeb.ServerRelativeUrl", so top-level segments are never created
# here; the library must already exist.
function Ensure-SiteFolder([Parameter(Mandatory)][string] $SiteRelativePath) {
    $segments = $SiteRelativePath.Trim('/') -split '/'
    $parent   = ''
    foreach ($seg in $segments) {
        $target = if ($parent) { "$parent/$seg" } else { $seg }
        if ($parent) {
            $exists = Get-PnPFolder -Url $target -ErrorAction SilentlyContinue
            if ($null -eq $exists) {
                Add-PnPFolder -Folder $parent -Name $seg -ErrorAction Stop | Out-Null
                Write-Item "Created folder /$target"
            } else {
                Write-Item "Folder /$target exists"
            }
        }
        $parent = $target
    }
}

# A freshly created communication site does NOT have the "Site Assets" library
# until something uses it. The template (and our folder prep) upload images to
# SiteAssets/Images, so any Add-PnPFolder / file upload under SiteAssets fails
# with "File Not Found" until the library is created. EnsureSiteAssetsLibrary()
# is the documented CSOM call that creates it on demand — this is the fix for
# the recurring "File Not Found" / "SharePoint Rest service exception" errors.
function Ensure-SiteAssetsLibrary {
    try {
        $ctx    = Get-PnPContext
        $assets = $ctx.Web.Lists.EnsureSiteAssetsLibrary()
        $ctx.Load($assets)
        $ctx.ExecuteQuery()
        Write-Item "Site Assets library ensured."
    } catch {
        # Fall back to Resolve-PnPFolder, then surface a clear error if both fail.
        try {
            Resolve-PnPFolder -SiteRelativePath "SiteAssets" -ErrorAction Stop | Out-Null
            Write-Item "Site Assets library ensured (via Resolve-PnPFolder)."
        } catch {
            throw "Could not create the Site Assets library on $($cfg.SiteUrl). The template's image uploads will fail without it. Underlying error: $($_.Exception.Message)"
        }
    }
}

# ---------------------------------------------------------------------------
# Logging — capture the ENTIRE run (not just the template phase) to a log in
# this script's folder, so any failure at any phase is recoverable. Both the
# console transcript and the detailed PnP framework trace are written here.
# ---------------------------------------------------------------------------
$LogStamp  = Get-Date -Format 'yyyyMMdd-HHmmss'
$DeployLog = Join-Path $PSScriptRoot "CopilotHub-deploy-$LogStamp.log"
$TraceLog  = Join-Path $PSScriptRoot "CopilotHub-pnptrace-$LogStamp.log"
try { Start-Transcript -Path $DeployLog -Force | Out-Null } catch { }

try {

# ---------------------------------------------------------------------------
# 0. Load config + sanity checks
# ---------------------------------------------------------------------------
if (-not (Test-Path $ConfigPath)) {
    throw "Config file not found: $ConfigPath"
}
$cfg = Import-PowerShellDataFile -Path $ConfigPath

foreach ($k in 'TenantUrl','SiteUrl','SiteTitle','CompanyName','Owner','Tenant','ClientId') {
    if ([string]::IsNullOrWhiteSpace($cfg.$k)) {
        if ($k -eq 'ClientId') {
            throw "Config.psd1 is missing ClientId. Run .\Register-PnPApp.ps1 -Tenant $($cfg.Tenant) first, then paste the ClientId into Config.psd1."
        }
        throw "Config.psd1 is missing required value: $k"
    }
}

# Optional organization links used throughout the pages. Anything left blank
# falls back to the support link, and the support link falls back to an email
# to the site owner, so no page ever ships with an empty or placeholder link.
function Resolve-OrgLink([string] $Key, [string] $Fallback, [string] $FallbackLabel) {
    $value = [string] $cfg.$Key
    if ([string]::IsNullOrWhiteSpace($value)) {
        $script:linkFallbacks += "$Key -> $FallbackLabel"
        return $Fallback
    }
    $value = $value.Trim()
    if ($value -notmatch '^(https://|mailto:)') {
        throw "Config.psd1 -> $Key must start with https:// or mailto: (got '$value')."
    }
    return $value
}
$script:linkFallbacks = @()
$SupportUrl        = Resolve-OrgLink 'SupportUrl'        "mailto:$($cfg.Owner)" "email to the site owner ($($cfg.Owner))"
$LicenseRequestUrl = Resolve-OrgLink 'LicenseRequestUrl' $SupportUrl 'SupportUrl'
$CommunityUrl      = Resolve-OrgLink 'CommunityUrl'      $SupportUrl 'SupportUrl'
$OfficeHoursUrl    = Resolve-OrgLink 'OfficeHoursUrl'    $SupportUrl 'SupportUrl'
$AIPolicyUrl       = Resolve-OrgLink 'AIPolicyUrl'       $SupportUrl 'SupportUrl'

$VersionPath = Join-Path $PSScriptRoot 'VERSION.txt'
$PackageVersion = if (Test-Path $VersionPath) { (Get-Content $VersionPath -Raw).Trim() } else { 'unknown' }
Write-Host "Copilot Hub package version $PackageVersion" -ForegroundColor Cyan
if ($script:linkFallbacks.Count -gt 0) {
    Write-Warn "These optional Config.psd1 links are blank and will use a fallback:"
    foreach ($f in $script:linkFallbacks) { Write-Warn "  $f" }
    Write-Warn "Fill them in and re-run to point people at your real support, license, community, office-hours, and AI-policy pages."
}

$SeedScriptPath          = Join-Path $PSScriptRoot 'Seed-LearningPaths.ps1'
$PromptSeedScriptPath    = Join-Path $PSScriptRoot 'Seed-PromptLibrary.ps1'
$LocalizationScriptPath  = Join-Path $PSScriptRoot 'Apply-Localization.ps1'
$AssetsFolder            = Join-Path $PSScriptRoot 'assets'

Write-Step "Checking PnP.PowerShell"
# The template was generated with PnP.Framework 1.10.2. PnP.PowerShell 1.12.x
# bundles the closest compatible framework version. Later major versions can
# change page-provisioning behavior, so fail rather than silently selecting one.
$allMods = Get-Module -ListAvailable -Name PnP.PowerShell | Sort-Object Version -Descending
if (-not $allMods) {
    # Documents is often redirected to OneDrive; ask Windows for the real folder.
    $moduleRoots = @(
        [IO.Path]::Combine([Environment]::GetFolderPath('MyDocuments'), 'PowerShell', 'Modules', 'PnP.PowerShell'),
        [IO.Path]::Combine($HOME, 'Documents', 'PowerShell', 'Modules', 'PnP.PowerShell')
    ) | Where-Object { Test-Path $_ } | Select-Object -Unique
    $moduleManifests = foreach ($root in $moduleRoots) {
        Get-ChildItem -Path $root -Filter 'PnP.PowerShell.psd1' -Recurse -ErrorAction SilentlyContinue
    }
    if ($moduleManifests) {
        $allMods = foreach ($manifest in $moduleManifests) {
            $version = $null
            if ([version]::TryParse($manifest.Directory.Name, [ref]$version)) {
                [pscustomobject]@{
                    Version = $version
                    Path    = $manifest.FullName
                }
            }
        }
    }
    if (-not $allMods) {
        throw "PnP.PowerShell is not installed. Run: Install-Module PnP.PowerShell -RequiredVersion 1.12.0 -Scope CurrentUser"
    }
}
# Require the tested 1.12.x line so the archive and implementation stay aligned.
$mod = $allMods | Where-Object { $_.Version -ge [version]'1.12' -and $_.Version -lt [version]'1.13' } |
       Select-Object -First 1
if (-not $mod) {
    throw "PnP.PowerShell 1.12.x is required for this template. Run: Install-Module PnP.PowerShell -RequiredVersion 1.12.0 -Scope CurrentUser"
}

# Force-import the selected version so newer versions already in the session
# do not shadow it.
Import-Module $mod.Path -Force -DisableNameChecking
Write-Item "Using PnP.PowerShell $($mod.Version)  (PnP.Framework compatibility: 1.10.x template)"

# Turn on the detailed PnP framework trace for the whole run. This is the log
# that surfaces the real server error (e.g. "File Not Found" / ServerException)
# behind the generic "SharePoint Rest service exception" console message.
Set-PnPTraceLog -On -LogFile $TraceLog -Level Debug
Write-Item "Trace log: $TraceLog"

$AdminUrl = $cfg.TenantUrl -replace '\.sharepoint\.com', '-admin.sharepoint.com'

# ---------------------------------------------------------------------------
# 2. Connect to tenant admin and ensure the site exists
# ---------------------------------------------------------------------------
Write-Step "Connecting to tenant admin: $AdminUrl"
Write-Item "Sign in as a SharePoint Administrator in the browser window."
Connect-PnPOnline -Url $AdminUrl -Interactive -ClientId $cfg.ClientId -Tenant $cfg.Tenant

Write-Step "Ensuring site exists: $($cfg.SiteUrl)"

# Step 1: Is the URL in the site recycle bin from a previous failed attempt?
# (PnP New-PnPSite will return SiteStatus:3 if the URL collides with a deleted site.)
$deleted = Get-PnPTenantDeletedSite -ErrorAction Stop |
    Where-Object { $_.Url -eq $cfg.SiteUrl }

if ($deleted) {
    Write-Warning "Found '$($cfg.SiteUrl)' in the SharePoint site recycle bin."
    if (-not $PurgeConflictingSite) {
        throw "A deleted site already uses $($cfg.SiteUrl). No site is removed automatically. Review it in the SharePoint admin center, then re-run with -PurgeConflictingSite only after explicit approval."
    }
    Write-Item "Permanently removing the recycled site because -PurgeConflictingSite was supplied."
    Remove-PnPTenantDeletedSite -Identity $cfg.SiteUrl -Force -ErrorAction Stop
    Write-Item "Recycled site purged. Waiting 60 seconds for tenant to release the URL..."
    Start-Sleep -Seconds 60
}

# Step 2: Probe current state.
$existing = Get-PnPTenantSite -Url $cfg.SiteUrl -ErrorAction SilentlyContinue

# A site in Error state (SiteStatus = 3) from a prior crashed deploy will keep
# blocking new creates. Treat it the same as deleted - purge and recreate.
if ($existing -and $existing.Status -eq 'Error') {
    Write-Warning "Existing site is in Error state."
    if (-not $PurgeConflictingSite) {
        throw "The site at $($cfg.SiteUrl) is in Error state. No site is removed automatically. Investigate it, then re-run with -PurgeConflictingSite only after explicit approval."
    }
    Write-Item "Removing the errored site because -PurgeConflictingSite was supplied."
    Remove-PnPTenantSite -Url $cfg.SiteUrl -Force -SkipRecycleBin -ErrorAction Stop
    Start-Sleep -Seconds 30
    $existing = $null
}

if ($null -eq $existing) {
    # Verify the Owner UPN actually resolves in this tenant BEFORE calling
    # New-PnPSite. GCC tenants reject bad owners with a generic SiteStatus:3.
    Write-Item "Verifying owner UPN '$($cfg.Owner)' resolves in tenant..."
    try {
        # Get-PnPEntraIDUser is the PnP 2.x successor; fall back to the old name for PnP 1.x.
        $ownerProbe = if (Get-Command Get-PnPEntraIDUser -ErrorAction SilentlyContinue) {
            Get-PnPEntraIDUser -Identity $cfg.Owner -ErrorAction Stop
        } else {
            Get-PnPAzureADUser -Identity $cfg.Owner -ErrorAction Stop
        }
        if ($null -eq $ownerProbe) { throw "Owner UPN not found in directory." }
        Write-Item "Owner OK: $($ownerProbe.DisplayName) <$($ownerProbe.UserPrincipalName)>"
    } catch {
        throw "Owner UPN '$($cfg.Owner)' could not be resolved in tenant $($cfg.Tenant). Update Config.psd1 -> Owner to a real licensed user (e.g. your own UPN) and re-run. Underlying error: $($_.Exception.Message)"
    }

    Write-Item "Creating communication site..."
    # NOTE: SiteDesign defaults to 'Topic'. On some GCC tenants the named
    # design 'Topic' isn't published - if creation fails specifically because
    # of that, the New-PnPSite call will error and we surface it as-is.
    try {
        New-PnPSite -Type CommunicationSite `
                    -Url   $cfg.SiteUrl `
                    -Title $cfg.SiteTitle `
                    -Owner $cfg.Owner `
                    -ErrorAction Stop | Out-Null
        Write-Item "Created."
    } catch {
        $msg = $_.Exception.Message
        if ($msg -match 'SiteStatus":3') {
            throw @"
Site creation returned an Error state. Most common causes on GCC / GCC-High:

  1. The URL '$($cfg.SiteUrl)' is reserved by another object (deleted site,
     M365 group, OneDrive). Check https://...-admin.sharepoint.com ->
     Sites -> Active sites AND Deleted sites for collisions.
  2. The Owner UPN '$($cfg.Owner)' isn't a real licensed cloud user.
  3. The signed-in account isn't a SharePoint or Global Administrator.
  4. The tenant has 'self-service site creation' disabled at the org level.

Underlying PnP error: $msg
"@
        } else {
            throw
        }
    }
} else {
    Write-Item "Site exists - skipping creation. (Status: $($existing.Status))"
}

# ---------------------------------------------------------------------------
# 2b. Register as hub site (while still connected to admin — avoids a second login)
# ---------------------------------------------------------------------------
if ($cfg.RegisterAsHub) {
    Write-Step "Registering as hub site (admin context)"
    $hub = Get-PnPHubSite -Identity $cfg.SiteUrl -ErrorAction SilentlyContinue
    if ($null -eq $hub) {
        Register-PnPHubSite -Site $cfg.SiteUrl | Out-Null
        Write-Item "Registered."
    } else {
        Write-Item "Already a hub - skipping."
    }
}

# ---------------------------------------------------------------------------
# 2c. Grant Site Collection Admin to the deploying user (admin context)
# ---------------------------------------------------------------------------
# The template's branding/chrome handlers — Site Footer, site logo (WebSettings)
# and Navigation — require Site Collection Administrator / Full Control. If the
# signed-in user is only a SharePoint (tenant) admin but NOT an SCA on THIS
# site, those handlers fail with "Access is denied (E_ACCESSDENIED 0x80070005)"
# or "SharePoint Rest service exception" and abort the apply before Navigation
# ever runs. The official Power Platform Hub deploy script fixes this by adding
# the current user as a site Owner before applying the template — do the same.
Write-Step "Granting Site Collection Admin to the deploying user"
try {
    $adminCtx = Get-PnPContext
    $adminCtx.Load($adminCtx.Web.CurrentUser)
    $adminCtx.ExecuteQuery()
    $currentUser = $adminCtx.Web.CurrentUser.Email
    if ($existing) {
        Write-Item "Existing site owners preserved; no tenant owner replacement performed."
    } else {
        $ownerSet = @($cfg.Owner)
        if (-not [string]::IsNullOrWhiteSpace($currentUser) -and ($currentUser -ne $cfg.Owner)) {
            $ownerSet += $currentUser
        }
        Set-PnPTenantSite -Identity $cfg.SiteUrl -Owners $ownerSet -ErrorAction Stop
        Write-Item "Site owners set: $($ownerSet -join ', ')"
        Write-Item "Waiting 15s for the permission change to propagate..."
        Start-Sleep -Seconds 15
    }
} catch {
    throw "Could not preserve site owners or grant the deploying user access. No template changes were applied. Underlying error: $($_.Exception.Message)"
}

# ---------------------------------------------------------------------------
# 3. Connect to the site and prepare destination folders
# ---------------------------------------------------------------------------
Write-Step "Connecting to site: $($cfg.SiteUrl)"
Connect-PnPOnline -Url $cfg.SiteUrl -Interactive -ClientId $cfg.ClientId -Tenant $cfg.Tenant

# The template writes pages under SitePages/Templates and uploads its embedded
# images to SiteAssets/Images. Both destination folders must exist BEFORE the
# template is applied, otherwise the first file upload fails with a
# 404 / FileNotFoundException that PnP reports as a REST service exception.
# On a brand-new communication site the "Site Assets" library itself does not
# exist yet, so create it first.
Write-Step "Preparing destination folders"
Ensure-SiteAssetsLibrary
Ensure-SiteFolder "SitePages/Templates"
Ensure-SiteFolder "SiteAssets/Images"

# ---------------------------------------------------------------------------
# 4. Apply CopilotHub.pnp — pages, navigation, Events list, stock images,
#    News carousel, QuickLinks, Events web part, rich layouts
#    (modeled after the official Power Platform adoption hub template)
# ---------------------------------------------------------------------------
Write-Step "Applying CopilotHub.pnp (rich pages, navigation, Events list)"
$pnpTemplatePath = Join-Path $PSScriptRoot 'template.pnp'
if (-not (Test-Path $pnpTemplatePath)) {
    throw "template.pnp not found at '$pnpTemplatePath'. Ensure the file is in the same folder as this script."
}

# The template's sample Events rows use date tokens in their EventDate/EndDate
# values. These MUST be supplied. If they are not, PnP leaves the tokens
# unresolved and feeds the literal text into list-item creation, which fails
# the whole apply with:
#   System.ArgumentException: serverRelativePath
#   "Specified value is not supported for the serverRelativePath parameter."
# The dates are weekdays in the month after deployment (1st Tuesday, 2nd
# Thursday, 3rd Wednesday, 4th Tuesday-Wednesday), so the sample events are
# upcoming on a fresh site and never fall on a weekend. Re-running the deploy
# moves them forward again; delete them once you add real events.
function Get-NthWeekday([datetime] $MonthStart, [DayOfWeek] $Day, [int] $N) {
    $first = $MonthStart
    while ($first.DayOfWeek -ne $Day) { $first = $first.AddDays(1) }
    return $first.AddDays(7 * ($N - 1))
}
$eventMonth     = (Get-Date -Day 1).Date.AddMonths(1)
$hackathonStart = Get-NthWeekday $eventMonth ([DayOfWeek]::Tuesday) 4
$templateParameters = @{
    CompanyName        = $cfg.CompanyName
    OfficeHoursDate    = (Get-NthWeekday $eventMonth ([DayOfWeek]::Tuesday) 1).ToString('yyyy-MM-dd')
    IntroSessionDate   = (Get-NthWeekday $eventMonth ([DayOfWeek]::Thursday) 2).ToString('yyyy-MM-dd')
    AgentSessionDate   = (Get-NthWeekday $eventMonth ([DayOfWeek]::Wednesday) 3).ToString('yyyy-MM-dd')
    HackathonStartDate = $hackathonStart.ToString('yyyy-MM-dd')
    HackathonEndDate   = $hackathonStart.AddDays(1).ToString('yyyy-MM-dd')
    SupportUrl         = $SupportUrl
    LicenseRequestUrl  = $LicenseRequestUrl
    CommunityUrl       = $CommunityUrl
    OfficeHoursUrl     = $OfficeHoursUrl
    AIPolicyUrl        = $AIPolicyUrl
}
Write-Item "Template parameters: CompanyName=$($templateParameters.CompanyName), sample events $($templateParameters.OfficeHoursDate) to $($templateParameters.HackathonEndDate)"

# Exclude the branding/chrome handlers. This is a GCC tenant, and the PnP chrome
# APIs (PnP Core SDK BrandingManager for the site header/footer, and the REST
# site-logo endpoint) throw "Access is denied (E_ACCESSDENIED 0x80070005)" there
# even for a Site Collection Admin — it is a GCC platform restriction, not a
# permission issue (the deploying user is already the site owner/SCA).
#
# The ACTUAL culprit is the **Site Header** handler (it sets a custom site header
# with a background image). Every run died immediately after the "Site Header"
# scope — earlier attempts excluded SiteFooter/WebSettings, which run AFTER Site
# Header, so they never took effect. Excluding the whole branding/settings
# cluster — SiteHeader, SiteFooter, WebSettings, PropertyBagEntries, SiteSettings,
# Theme, ComposedLook (property-bag writes are also blocked on NoScript sites) —
# lets the apply reach the Navigation handler (classic CSOM, works on GCC).
#
# Nothing important is lost: page-level headers come from the ClientSidePages
# handler (kept); the site logo is set best-effort in the branded-assets phase.
try {
    Invoke-PnPSiteTemplate -Path $pnpTemplatePath `
        -Parameters $templateParameters `
        -ExcludeHandlers SiteHeader, SiteFooter, WebSettings, PropertyBagEntries, SiteSettings, Theme, ComposedLook `
        -ErrorAction Stop
    Write-Item "Template applied (branding/chrome handlers excluded for GCC)."
} catch {
    $inner = if ($_.Exception.InnerException) { " | Inner: $($_.Exception.InnerException.Message)" } else { "" }
    throw "Template apply failed. Full run log: '$DeployLog' | PnP trace: '$TraceLog'. Error: $($_.Exception.Message)$inner"
}

# ---------------------------------------------------------------------------
# 4b. Sharing and site hardening
#     The WebSettings and SiteSettings handlers are excluded above, so the
#     template's MembersCanShare / Designer / workflow values are never applied
#     by Invoke-PnPSiteTemplate. Apply them explicitly here. Each setting is
#     best-effort: a failure is reported but does not stop the deployment.
# ---------------------------------------------------------------------------
Write-Step "Applying sharing and site hardening"
try {
    Set-PnPWeb -MembersCanShare:$false -ErrorAction Stop
    Write-Item "Site members can share: off (only owners can share the site and its content)"
} catch {
    Write-Warn "warn  : could not turn off member sharing ($($_.Exception.Message)). Set it in Site permissions -> Change how members can share."
}
try {
    $hardenCtx  = Get-PnPContext
    $hardenSite = $hardenCtx.Site
    $hardenCtx.Load($hardenSite)
    $hardenCtx.ExecuteQuery()
    $hardenSite.AllowDesigner                          = $false
    $hardenSite.AllowCreateDeclarativeWorkflow         = $false
    $hardenSite.AllowSaveDeclarativeWorkflowAsTemplate = $false
    $hardenSite.AllowSavePublishDeclarativeWorkflow    = $false
    $hardenCtx.ExecuteQuery()
    Write-Item "SharePoint Designer and declarative workflows: off"
} catch {
    Write-Warn "warn  : could not turn off SharePoint Designer / declarative workflow settings ($($_.Exception.Message))."
}

# ---------------------------------------------------------------------------
# 5. Site columns
# ---------------------------------------------------------------------------
Write-Step "Ensuring site columns"

# Choice columns are created with every choice below. On an existing site,
# choices added in a newer release are appended to the existing column, so a
# re-run upgrades the column without touching values already in use.
$siteColumns = @(
    @{ Name="CopilotProduct";         DisplayName="Product";            Type="Choice";
       Choices=@("Copilot Chat","Microsoft 365 Copilot","Copilot Cowork","Researcher","Analyst","Microsoft 365 Agents",
                 "SharePoint agents","Copilot Studio","Microsoft Foundry","GitHub Copilot","All") },
    @{ Name="CopilotAudience";        DisplayName="Audience";           Type="Choice";
       Choices=@("End User","Maker","Admin","Developer","Leader","All") },
    @{ Name="CopilotRequirement";     DisplayName="Requirement";        Type="Choice";
       Choices=@("Required","Recommended","Optional") },
    @{ Name="CopilotDurationMinutes"; DisplayName="Duration (minutes)"; Type="Number" },
    @{ Name="CopilotLevel";           DisplayName="Level";              Type="Choice";
       Choices=@("Beginner","Intermediate","Advanced") },
    @{ Name="CopilotLearnUrl";        DisplayName="Learn URL";          Type="URL" },
    @{ Name="CopilotOwner";           DisplayName="Owner";              Type="User" },
    @{ Name="CopilotConnector";       DisplayName="Connector";          Type="Text" },
    @{ Name="CopilotApprovalState";   DisplayName="Approval State";     Type="Choice";
       Choices=@("Submitted","In Review","Approved","Rejected","Retired") },
    @{ Name="CopilotPromptText";      DisplayName="Prompt";             Type="Note" },
    @{ Name="CopilotApp";             DisplayName="Works in";           Type="Choice";
       Choices=@("Copilot Chat","Word","Excel","PowerPoint","Outlook","Teams","Researcher","Analyst",
                 "Agent Builder","Code editor","Any") },
    @{ Name="CopilotDescription";     DisplayName="Description";        Type="Note" },
    @{ Name="CopilotAgentUrl";        DisplayName="Open link";          Type="URL" },
    @{ Name="CopilotDataSources";     DisplayName="Data it uses";       Type="Note" }
)

function Add-MissingChoices([string] $InternalName, [string[]] $Choices) {
    $ctx   = Get-PnPContext
    $field = $ctx.Web.Fields.GetByInternalNameOrTitle($InternalName)
    $castTo = [Microsoft.SharePoint.Client.ClientRuntimeContext].GetMethod('CastTo').MakeGenericMethod([Microsoft.SharePoint.Client.FieldChoice])
    $choiceField = $castTo.Invoke($ctx, @($field))
    $ctx.Load($choiceField)
    $ctx.ExecuteQuery()
    $missingChoices = @($Choices | Where-Object { $choiceField.Choices -notcontains $_ })
    if ($missingChoices.Count -gt 0) {
        $choiceField.Choices = [string[]] (@($choiceField.Choices) + $missingChoices)
        $choiceField.UpdateAndPushChanges($true)
        $ctx.ExecuteQuery()
    }
    return $missingChoices
}

foreach ($f in $siteColumns) {
    $existingField = Get-PnPField -Identity $f.Name -ErrorAction SilentlyContinue
    if ($existingField) {
        if ($f.Choices) {
            try {
                $addedChoices = @(Add-MissingChoices -InternalName $f.Name -Choices $f.Choices)
                if ($addedChoices.Count -gt 0) {
                    Write-Item "update: $($f.Name) (+ $($addedChoices -join ', '))"
                } else {
                    Write-Item "skip  : $($f.Name)"
                }
            } catch {
                Write-Warn "warn  : could not add new choices to $($f.Name) ($($_.Exception.Message)). Add them in Site settings -> Site columns."
            }
        } else {
            Write-Item "skip  : $($f.Name)"
        }
        continue
    }
    $params = @{
        InternalName = $f.Name
        DisplayName  = $f.DisplayName
        Type         = $f.Type
        Group        = "Copilot Hub"
    }
    if ($f.Choices) { $params.Choices = $f.Choices }
    Add-PnPField @params | Out-Null
    Write-Item "add   : $($f.Name)"
}

# ---------------------------------------------------------------------------
# 6. Lists
# ---------------------------------------------------------------------------
Write-Step "Ensuring lists"

$lists = @(
    @{ Title="Learning Paths";      Template="GenericList"; Url="Lists/LearningPaths";
       FieldRefs=@("CopilotProduct","CopilotAudience","CopilotRequirement",
                   "CopilotDurationMinutes","CopilotLevel","CopilotLearnUrl","CopilotOwner") },
    @{ Title="Agent Catalog";       Template="GenericList"; Url="Lists/AgentCatalog";
       FieldRefs=@("CopilotDescription","CopilotProduct","CopilotAudience","CopilotAgentUrl",
                   "CopilotDataSources","CopilotOwner","CopilotApprovalState") },
    @{ Title="Approved Connectors"; Template="GenericList"; Url="Lists/ApprovedConnectors";
       FieldRefs=@("CopilotConnector","CopilotDescription","CopilotApprovalState","CopilotOwner") },
    @{ Title="Prompt Library";      Template="GenericList"; Url="Lists/PromptLibrary";
       FieldRefs=@("CopilotPromptText","CopilotDescription","CopilotProduct","CopilotApp",
                   "CopilotAudience","CopilotOwner","CopilotApprovalState") }
    # Events list is provisioned by template.pnp (template phase)
)

foreach ($l in $lists) {
    $existingList = Get-PnPList -Identity $l.Title -ErrorAction SilentlyContinue
    if ($null -eq $existingList) {
        # No -OnQuickLaunch: on a communication site that would append raw list
        # links to the site navigation. The pages link to the lists instead.
        New-PnPList -Title $l.Title -Template $l.Template -Url $l.Url -EnableVersioning | Out-Null
        Write-Item "add   : $($l.Title)"
    } else {
        Write-Item "skip  : $($l.Title)"
    }
    foreach ($fieldName in $l.FieldRefs) {
        $lf = Get-PnPField -List $l.Title -Identity $fieldName -ErrorAction SilentlyContinue
        if ($null -eq $lf) {
            Add-PnPField -List $l.Title -Field $fieldName | Out-Null
            Write-Item "        + field: $fieldName"
        }
    }
    try {
        $defaultView = Get-PnPView -List $l.Title | Where-Object { $_.DefaultView } | Select-Object -First 1
        if ($defaultView) {
            Set-PnPView -List $l.Title -Identity $defaultView.Id -Fields (@("LinkTitle") + $l.FieldRefs) | Out-Null
        }
    } catch {
        Write-Warn "warn  : could not update the default view columns of $($l.Title) ($($_.Exception.Message))"
    }
}

# ---------------------------------------------------------------------------
# 7. Custom views
# ---------------------------------------------------------------------------
Write-Step "Ensuring list views"

$approvedOnly = "<Where><Eq><FieldRef Name='CopilotApprovalState' /><Value Type='Choice'>Approved</Value></Eq></Where>"
$views = @(
    @{ List = "Learning Paths"; Title = "By Audience"; SetDefault = $true
       Fields = @("LinkTitle","CopilotProduct","CopilotAudience","CopilotRequirement",
                  "CopilotDurationMinutes","CopilotLevel","CopilotLearnUrl")
       Query  = "<GroupBy Collapse='FALSE' GroupLimit='30'><FieldRef Name='CopilotAudience' /></GroupBy><OrderBy><FieldRef Name='CopilotRequirement' /><FieldRef Name='Title' /></OrderBy>" },
    @{ List = "Learning Paths"; Title = "By Product"
       Fields = @("LinkTitle","CopilotAudience","CopilotRequirement",
                  "CopilotDurationMinutes","CopilotLevel","CopilotLearnUrl")
       Query  = "<GroupBy Collapse='FALSE' GroupLimit='30'><FieldRef Name='CopilotProduct' /></GroupBy><OrderBy><FieldRef Name='Title' /></OrderBy>" },
    @{ List = "Learning Paths"; Title = "Required Only"
       Fields = @("LinkTitle","CopilotProduct","CopilotAudience","CopilotDurationMinutes","CopilotLearnUrl")
       Query  = "<Where><Eq><FieldRef Name='CopilotRequirement' /><Value Type='Choice'>Required</Value></Eq></Where>" },
    @{ List = "Prompt Library"; Title = "Approved prompts"
       Fields = @("LinkTitle","CopilotPromptText","CopilotApp","CopilotProduct","CopilotAudience","CopilotDescription")
       Query  = "$approvedOnly<OrderBy><FieldRef Name='CopilotApp' /><FieldRef Name='Title' /></OrderBy>" },
    @{ List = "Agent Catalog"; Title = "Approved agents"
       Fields = @("LinkTitle","CopilotDescription","CopilotProduct","CopilotAudience","CopilotAgentUrl","CopilotDataSources","CopilotOwner")
       Query  = "$approvedOnly<OrderBy><FieldRef Name='Title' /></OrderBy>" }
)

foreach ($v in $views) {
    $existingView = Get-PnPView -List $v.List -Identity $v.Title -ErrorAction SilentlyContinue
    if ($null -eq $existingView) {
        $params = @{
            List       = $v.List
            Title      = $v.Title
            Fields     = $v.Fields
            Query      = $v.Query
            ViewType   = "Html"
        }
        if ($v.SetDefault) { $params.SetAsDefault = $true }
        Add-PnPView @params | Out-Null
        Write-Item "add   : $($v.List) / $($v.Title)"
    } else {
        Write-Item "skip  : $($v.List) / $($v.Title)"
    }
}

# ---------------------------------------------------------------------------
# 8. Branded assets (upload PNGs to /SiteAssets/CopilotHub/ and set logo)
# ---------------------------------------------------------------------------
Write-Step "Uploading branded assets"

if (Test-Path $AssetsFolder) {
    $assetFolderRel = "SiteAssets/CopilotHub"
    Ensure-SiteFolder $assetFolderRel
    foreach ($asset in (Get-ChildItem -Path $AssetsFolder -Filter *.png -File)) {
        Add-PnPFile -Path $asset.FullName -Folder $assetFolderRel | Out-Null
        Write-Item "upload: $($asset.Name)"
    }

    # Set the site logo from the local site-logo.png (if present)
    $localLogo = Join-Path $AssetsFolder 'site-logo.png'
    if (Test-Path $localLogo) {
        try {
            Set-PnPSite -LogoFilePath $localLogo -ErrorAction Stop
            Write-Item "Site logo set."
        } catch {
            Write-Warn "note  : could not set site logo via Set-PnPSite ($($_.Exception.Message))"
        }
    }
} else {
    Write-Warn "Assets folder not found at $AssetsFolder - skipping asset upload. Welcome page images will 404 until assets are uploaded."
}

# ---------------------------------------------------------------------------
# 9. Seed Learning Paths and starter prompts (reuse the existing site
#    connection — no extra browser prompt)
# ---------------------------------------------------------------------------
if (Test-Path $SeedScriptPath) {
    Write-Step "Seeding Learning Paths list"
    & $SeedScriptPath -ConfigPath $ConfigPath -SkipConnect
} else {
    Write-Warning "Seed script not found at $SeedScriptPath - skipping data seed"
}
if (Test-Path $PromptSeedScriptPath) {
    Write-Step "Seeding starter prompts"
    & $PromptSeedScriptPath -ConfigPath $ConfigPath -SkipConnect
} else {
    Write-Warning "Prompt seed script not found at $PromptSeedScriptPath - skipping starter prompts"
}

# ---------------------------------------------------------------------------
# 9b. Embed the approved-prompts and approved-agents views on their pages.
#     The lists are created after the template, so the embedded views are added
#     here. The pages also link to the lists, so a failure here is not fatal.
# ---------------------------------------------------------------------------
Write-Step "Embedding list views on the Prompt library and Agent catalog pages"
$listWebPartId = 'f92bf067-bc19-489e-a556-7fe95f508720'
$embeds = @(
    @{ Page = "Prompt-Library.aspx"; List = "Prompt Library"; View = "Approved prompts" },
    @{ Page = "Agent-Catalog.aspx";  List = "Agent Catalog";  View = "Approved agents" }
)
foreach ($e in $embeds) {
    try {
        $components = @(Get-PnPPageComponent -Page $e.Page -ErrorAction Stop)
        $hasList = @($components | Where-Object {
            ($_.PSObject.Properties['WebPartId'] -and $_.WebPartId -eq $listWebPartId) -or
            ($_.PSObject.Properties['Title'] -and $_.Title -eq 'List')
        }).Count -gt 0
        if ($hasList) {
            Write-Item "skip  : $($e.Page) already shows a list"
            continue
        }
        $list = Get-PnPList -Identity $e.List -ErrorAction Stop
        $view = Get-PnPView -List $e.List -Identity $e.View -ErrorAction Stop
        Add-PnPPageWebPart -Page $e.Page -DefaultWebPartType List -Section 1 -Column 1 -Order 10 -WebPartProperties @{
            isDocumentLibrary = $false
            selectedListId    = $list.Id.ToString()
            selectedViewId    = $view.Id.ToString()
            hideCommandBar    = $false
        } -ErrorAction Stop | Out-Null
        Set-PnPPage -Identity $e.Page -Publish -ErrorAction Stop | Out-Null
        Write-Item "add   : '$($e.View)' view on $($e.Page)"
    } catch {
        Write-Warn "warn  : could not embed '$($e.View)' on $($e.Page) ($($_.Exception.Message)). The page still links to the list; add a List web part manually if needed."
    }
}

# ---------------------------------------------------------------------------
# 10. Optional localization pass (reuse existing site connection — no extra
#     browser prompt). The English base site above is always deployed first;
#     this step only renames existing navigation, pages, site columns, and
#     lists to the localized labels in .\localization\<Locale>\content.json.
# ---------------------------------------------------------------------------
if ($Locale) {
    if (Test-Path $LocalizationScriptPath) {
        Write-Step "Applying localization pack: $Locale"
        & $LocalizationScriptPath -ConfigPath $ConfigPath -Locale $Locale -SkipConnect
    } else {
        Write-Warning "Localization script not found at $LocalizationScriptPath - skipping localization"
    }
}

Write-Step "Done"
Write-Host ""
Write-Host "  Copilot Hub $PackageVersion is live at: $($cfg.SiteUrl)" -ForegroundColor Green
if ($script:linkFallbacks.Count -gt 0) {
    Write-Warn "  Reminder: $($script:linkFallbacks.Count) organization link(s) in Config.psd1 are blank and use a fallback (see the start of this log)."
}
Write-Host "  Before announcing the site, review the sample events, starter prompts, and launch news posts." -ForegroundColor DarkGray
Write-Host "  Re-run this script any time to push template changes." -ForegroundColor DarkGray
Write-Host "  Run log: $DeployLog" -ForegroundColor DarkGray
Write-Host ""

}
finally {
    # Always release the trace log and close the transcript, even if the run
    # threw. This guarantees a complete log lands in the script folder for
    # every deploy attempt.
    try { Set-PnPTraceLog -Off } catch { }
    try { Stop-Transcript | Out-Null } catch { }
}
